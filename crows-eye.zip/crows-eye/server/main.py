"""Crow's Eye API server. Run: python -m server.main"""
import asyncio, ipaddress, json, os, random, re, secrets, time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import core, db, engine, security as sec
from .db import q

viewer, analyst, admin = sec.need("viewer"), sec.need("analyst"), sec.need("admin")

# ---------------- startup ----------------
def bootstrap_admin():
    if q("SELECT COUNT(*) n FROM users", one=True)["n"]: return
    pw = os.getenv("CROWS_EYE_ADMIN_PASSWORD") or secrets.token_urlsafe(12)
    db.insert("INSERT INTO users(username,pw_hash,role,created) VALUES(?,?,?,?)", ("admin", sec.hash_pw(pw), "admin", time.time()))
    print(f"\n  First run: created user 'admin' with password: {pw}\n  (change it in Settings > Users)\n")

@asynccontextmanager
async def lifespan(app):
    core.set_loop(asyncio.get_running_loop())
    bootstrap_admin(); engine.seed_rules(); engine.start_worker()
    tasks = [asyncio.create_task(core.housekeeping())]
    if db.DEMO: tasks.append(asyncio.create_task(demo_loop()))
    yield
    for t in tasks: t.cancel()
    core.set_loop(None)

app = FastAPI(title="Crow's Eye", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)

@app.middleware("http")
async def headers(request: Request, call_next):
    if int(request.headers.get("content-length") or 0) > 4_000_000:
        return JSONResponse({"detail": "Payload too large"}, 413)
    r = await call_next(request)
    r.headers.update({"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
                      "Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
                      "font-src https://fonts.gstatic.com; img-src 'self' data:; frame-ancestors 'none'"})
    if request.url.path.startswith("/api/") and "cache-control" not in r.headers: r.headers["Cache-Control"] = "no-store"
    return r

@app.get("/healthz")
def healthz(): return {"ok": True}

# ---------------- auth & users ----------------
class LoginIn(BaseModel): username: str = Field(max_length=64); password: str = Field(max_length=200)

@app.post("/api/auth/login")
def login(b: LoginIn, request: Request, response: Response):
    key = (sec.client_ip(request), b.username.lower())
    if sec.throttled(key): raise HTTPException(429, "Too many failed attempts; try again in a few minutes")
    u = q("SELECT * FROM users WHERE username=? AND disabled=0", (b.username,), one=True)
    ok = sec.check_pw(b.password, u["pw_hash"] if u else sec.hash_pw("x" * 12))   # constant-ish time for unknown users
    if not (u and ok):
        sec.record_fail(key); db.audit(b.username[:64], "login_failed", key[0]); raise HTTPException(401, "Invalid username or password")
    sec.clear_fails(key)
    token, csrf = sec.create_session(u["id"])
    response.set_cookie(sec.COOKIE, token, httponly=True, samesite="strict", secure=sec.SECURE_COOKIES, max_age=sec.SESSION_TTL, path="/")
    db.audit(u["username"], "login", key[0])
    return {"username": u["username"], "role": u["role"], "csrf": csrf}

@app.get("/api/auth/me")
def me(request: Request):
    u = sec.current_user(request)
    if not u: raise HTTPException(401, "Not authenticated")
    return {"username": u["username"], "role": u["role"], "csrf": u["csrf"]}

@app.post("/api/auth/logout")
def logout(request: Request, response: Response, u=Depends(viewer)):
    q("DELETE FROM sessions WHERE token_hash=?", (sec.sha(request.cookies.get(sec.COOKIE, "")),))
    response.delete_cookie(sec.COOKIE, path="/"); return {"ok": True}

class PwChange(BaseModel): current: str = Field(max_length=200); new: str = Field(max_length=200)

@app.post("/api/auth/password")
def change_password(b: PwChange, request: Request, u=Depends(viewer)):
    row = q("SELECT pw_hash FROM users WHERE id=?", (u["id"],), one=True)
    if not sec.check_pw(b.current, row["pw_hash"]): raise HTTPException(403, "Current password is incorrect")
    sec.valid_password(b.new)
    q("UPDATE users SET pw_hash=? WHERE id=?", (sec.hash_pw(b.new), u["id"]))
    q("DELETE FROM sessions WHERE user_id=? AND token_hash!=?", (u["id"], sec.sha(request.cookies.get(sec.COOKIE, ""))))
    db.audit(u["username"], "password_change"); return {"ok": True}

class UserIn(BaseModel):
    username: str = Field(pattern=r"^[A-Za-z0-9_.-]{2,40}$"); password: str; role: str = "viewer"
class UserPatch(BaseModel):
    role: Optional[str] = None; disabled: Optional[bool] = None; password: Optional[str] = None

def _admins_left(excluding: int) -> int:
    return q("SELECT COUNT(*) n FROM users WHERE role='admin' AND disabled=0 AND id!=?", (excluding,), one=True)["n"]

@app.get("/api/users")
def users(u=Depends(admin)): return q("SELECT id,username,role,disabled,created FROM users ORDER BY username")

@app.post("/api/users")
def create_user(b: UserIn, u=Depends(admin)):
    if b.role not in sec.ROLES: raise HTTPException(422, "Invalid role")
    sec.valid_password(b.password)
    if q("SELECT 1 FROM users WHERE username=?", (b.username,), one=True): raise HTTPException(409, "Username exists")
    db.insert("INSERT INTO users(username,pw_hash,role,created) VALUES(?,?,?,?)", (b.username, sec.hash_pw(b.password), b.role, time.time()))
    db.audit(u["username"], "user_create", f"{b.username} ({b.role})"); return {"ok": True}

@app.patch("/api/users/{uid}")
def patch_user(uid: int, b: UserPatch, u=Depends(admin)):
    t = q("SELECT * FROM users WHERE id=?", (uid,), one=True)
    if not t: raise HTTPException(404, "No such user")
    if b.role is not None and b.role not in sec.ROLES: raise HTTPException(422, "Invalid role")
    if (b.disabled or (b.role and b.role != "admin")) and t["role"] == "admin" and _admins_left(uid) == 0:
        raise HTTPException(409, "Cannot remove the last active admin")
    if b.role is not None: q("UPDATE users SET role=? WHERE id=?", (b.role, uid))
    if b.disabled is not None: q("UPDATE users SET disabled=? WHERE id=?", (int(b.disabled), uid))
    if b.password is not None:
        sec.valid_password(b.password); q("UPDATE users SET pw_hash=? WHERE id=?", (sec.hash_pw(b.password), uid))
    if b.password is not None or b.disabled: q("DELETE FROM sessions WHERE user_id=?", (uid,))
    db.audit(u["username"], "user_update", t["username"]); return {"ok": True}

@app.delete("/api/users/{uid}")
def delete_user(uid: int, u=Depends(admin)):
    t = q("SELECT * FROM users WHERE id=?", (uid,), one=True)
    if not t: raise HTTPException(404, "No such user")
    if t["role"] == "admin" and _admins_left(uid) == 0: raise HTTPException(409, "Cannot delete the last active admin")
    q("DELETE FROM users WHERE id=?", (uid,)); db.audit(u["username"], "user_delete", t["username"]); return {"ok": True}

# ---------------- API keys ----------------
class KeyIn(BaseModel):
    name: str = Field(min_length=1, max_length=80); kind: str = "agent"
    hostname: Optional[str] = Field(default=None, pattern=r"^[A-Za-z0-9_.-]{1,100}$")

@app.get("/api/keys")
def keys(u=Depends(admin)): return q("SELECT id,name,kind,hostname,created,last_used,revoked FROM api_keys ORDER BY id DESC")

@app.post("/api/keys")
def create_key(b: KeyIn, u=Depends(admin)):
    if b.kind not in ("agent", "integration"): raise HTTPException(422, "kind must be agent or integration")
    if b.kind == "agent" and not b.hostname: raise HTTPException(422, "Agent keys need a hostname")
    kid, key = sec.new_key(b.name, b.kind, b.hostname if b.kind == "agent" else None)
    db.audit(u["username"], "key_create", f"{b.kind}:{b.name}"); return {"id": kid, "key": key}   # shown once

@app.delete("/api/keys/{kid}")
def revoke_key(kid: int, u=Depends(admin)):
    q("UPDATE api_keys SET revoked=1 WHERE id=?", (kid,)); db.audit(u["username"], "key_revoke", str(kid)); return {"ok": True}

# ---------------- settings ----------------
@app.get("/api/settings")
def get_settings(u=Depends(admin)): return db.all_settings()

@app.put("/api/settings")
def put_settings(b: dict, u=Depends(admin)):
    out = {}
    for k, v in b.items():
        if k not in db.DEFAULTS: raise HTTPException(422, f"Unknown setting {k}")
        d = db.DEFAULTS[k]
        if isinstance(d, bool): v = bool(v)
        elif isinstance(d, int): v = int(v)
        elif isinstance(d, list): v = [str(x).strip() for x in v][:5000]
        else: v = str(v).strip()[:500]
        out[k] = v
    if "offline_after" in out and not 30 <= out["offline_after"] <= 3600: raise HTTPException(422, "offline_after: 30-3600")
    if "retention_days" in out and not 1 <= out["retention_days"] <= 365: raise HTTPException(422, "retention_days: 1-365")
    for k in ("webhook_min_severity", "email_min_severity"):
        if k in out and out[k] not in db.SEVERITIES: raise HTTPException(422, f"{k} invalid")
    if out.get("webhook_url") and not out["webhook_url"].startswith(("http://", "https://")): raise HTTPException(422, "Webhook URL must be http(s)")
    for x in out.get("blocklist", []):
        try: ipaddress.ip_network(x, strict=False)
        except ValueError: raise HTTPException(422, f"Invalid IP/CIDR in blocklist: {x[:60]}")
    db.set_settings(out); db.audit(u["username"], "settings_update", ", ".join(out)); return db.all_settings()

@app.post("/api/settings/test-notification")
def test_notification(u=Depends(admin)):
    s, t = db.all_settings(), {"id": 0, "severity": "LOW", "name": "Test notification", "source": "settings", "device": "crows-eye",
                              "ts": time.time(), "status": "Monitoring"}
    res = {}
    for name, on, fn in (("webhook", bool(s["webhook_url"]), lambda: engine.send_webhook(s["webhook_url"], t)),
                         ("email", s["email_enabled"], lambda: engine.send_email(s, t))):
        if on:
            try: fn(); res[name] = "sent"
            except Exception as e: res[name] = f"failed: {e}"
    return res or {"info": "No notification channel is enabled"}

# ---------------- rules ----------------
class Cond(BaseModel): field: str = Field(max_length=40); op: str; value: object = None
class Threshold(BaseModel): count: int; window: int; group_by: Optional[str] = Field(default=None, max_length=40)
class RuleIn(BaseModel):
    name: str = Field(min_length=1, max_length=120); enabled: bool = True; severity: str; kind: str
    match: list[Cond] = Field(default_factory=list, max_length=10); threshold: Optional[Threshold] = None; cooldown: int = 300

def _rule_row(b: RuleIn):
    d = {"severity": b.severity.upper(), "kind": b.kind, "cooldown": b.cooldown,
         "match": [c.model_dump() for c in b.match], "threshold": b.threshold.model_dump() if b.threshold else None}
    err = engine.validate_rule(d)
    if err: raise HTTPException(422, err)
    return d

@app.get("/api/rules")
def rules(u=Depends(viewer)):
    rows = q("SELECT * FROM rules ORDER BY id")
    for r in rows: r["match"] = json.loads(r["match"]); r["threshold"] = json.loads(r["threshold"] or "null")
    return {"rules": rows, "kinds": engine.KINDS, "ops": engine.OPS}

@app.post("/api/rules")
def create_rule(b: RuleIn, u=Depends(admin)):
    d = _rule_row(b)
    rid = db.insert("INSERT INTO rules(name,enabled,severity,kind,match,threshold,cooldown) VALUES(?,?,?,?,?,?,?)",
                    (b.name, int(b.enabled), d["severity"], d["kind"], json.dumps(d["match"]), json.dumps(d["threshold"]), d["cooldown"]))
    engine.reload_rules(); db.audit(u["username"], "rule_create", b.name); return {"id": rid}

@app.put("/api/rules/{rid}")
def update_rule(rid: int, b: RuleIn, u=Depends(admin)):
    d = _rule_row(b)
    if not q("SELECT 1 FROM rules WHERE id=?", (rid,), one=True): raise HTTPException(404, "No such rule")
    q("UPDATE rules SET name=?,enabled=?,severity=?,kind=?,match=?,threshold=?,cooldown=? WHERE id=?",
      (b.name, int(b.enabled), d["severity"], d["kind"], json.dumps(d["match"]), json.dumps(d["threshold"]), d["cooldown"], rid))
    engine.reload_rules(); db.audit(u["username"], "rule_update", b.name); return {"ok": True}

@app.delete("/api/rules/{rid}")
def delete_rule(rid: int, u=Depends(admin)):
    q("DELETE FROM rules WHERE id=?", (rid,)); engine.reload_rules(); db.audit(u["username"], "rule_delete", str(rid)); return {"ok": True}

# ---------------- agent + integration ingest (API keys) ----------------
class ReportIn(BaseModel):
    os: Optional[str] = Field(default=None, max_length=100); ip: Optional[str] = Field(default=None, max_length=64)
    version: Optional[str] = Field(default=None, max_length=32)
    metrics: Optional[dict] = None; traffic: Optional[dict] = None
    events: list[dict] = Field(default_factory=list, max_length=500)

@app.post("/api/agent/report")
def agent_report(b: ReportIn, key=Depends(sec.key_auth("agent"))):
    return core.process_report(key["hostname"], b)      # device identity is bound to the key

class ThreatIn(BaseModel):
    severity: str; name: str = Field(min_length=1, max_length=200); source: str = Field(default="unknown", max_length=200)
    device: str = Field(min_length=1, max_length=100); detail: str = Field(default="", max_length=4000)

@app.post("/api/ingest/events")
def ingest_threat(b: ThreatIn, key=Depends(sec.key_auth("integration"))):
    if b.severity.upper() not in db.SEVERITIES: raise HTTPException(422, "Invalid severity")
    return {"id": core.add_threat(b.severity, b.name, b.source, b.device, b.detail)["id"]}

@app.post("/api/ingest/wazuh")
def ingest_wazuh(alert: dict, key=Depends(sec.key_auth("integration"))):
    try: lvl = int((alert.get("rule") or {}).get("level") or 0)
    except (TypeError, ValueError): lvl = 0
    sev = "CRITICAL" if lvl >= 12 else "HIGH" if lvl >= 10 else "MEDIUM" if lvl >= 7 else "LOW"
    agent, data = alert.get("agent") or {}, alert.get("data") or {}
    dev = str(agent.get("name") or "WAZUH-SERVER")[:100]
    t = core.add_threat(sev, str((alert.get("rule") or {}).get("description") or "Wazuh alert")[:200], str(data.get("srcip") or "Wazuh")[:200],
                        dev, json.dumps(alert)[:4000])
    return {"id": t["id"]}

# ---------------- dashboard reads ----------------
@app.get("/api/overview")
def overview(u=Depends(viewer)): return core.overview()

@app.get("/api/devices")
def devices(u=Depends(viewer)): return core.devices()

@app.get("/api/devices/{hostname}")
def device_detail(hostname: str, u=Depends(viewer)):
    d = next((x for x in core.devices() if x["hostname"].lower() == hostname.lower()), None)
    if not d: raise HTTPException(404, "No such device")
    ev = q("SELECT id,ts,kind,data FROM events WHERE device=? ORDER BY id DESC LIMIT 50", (d["hostname"],))
    for e in ev: e["data"] = json.loads(e["data"])
    return {"device": d, "events": ev, "threats": q("SELECT id,ts,severity,name,status FROM threats WHERE device=? COLLATE NOCASE ORDER BY ts DESC LIMIT 20", (d["hostname"],)),
            "metrics": q("SELECT ts,cpu,mem,disk FROM metrics WHERE device=? AND ts>? ORDER BY ts", (d["hostname"], time.time() - 3 * 3600))[::6]}

@app.delete("/api/devices/{hostname}")
def delete_device(hostname: str, u=Depends(admin)):
    q("DELETE FROM devices WHERE hostname=?", (hostname,)); q("DELETE FROM metrics WHERE device=?", (hostname,))
    q("UPDATE api_keys SET revoked=1 WHERE hostname=? COLLATE NOCASE", (hostname,))
    db.audit(u["username"], "device_delete", hostname); return {"ok": True}

@app.get("/api/network")
def network(u=Depends(viewer)): return core.network()

@app.get("/api/threats")
def threats(status: Optional[str] = None, severity: Optional[str] = None, device: Optional[str] = None, qs: Optional[str] = Query(None, alias="q"),
            limit: int = Query(100, ge=1, le=500), offset: int = Query(0, ge=0), u=Depends(viewer)):
    where, args = [], []
    for col, val in (("status", status), ("severity", severity and severity.upper()), ("device", device)):
        if val: where.append(f"{col}=? COLLATE NOCASE"); args.append(val)
    if qs:
        like = "%" + qs.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        where.append("(name LIKE ? ESCAPE '\\' OR source LIKE ? ESCAPE '\\' OR device LIKE ? ESCAPE '\\')"); args += [like] * 3
    sql = "SELECT * FROM threats" + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY ts DESC LIMIT ? OFFSET ?"
    rows = q(sql, (*args, limit, offset))
    for r in rows: r["detail"] = r["detail"][:300] if r["detail"] else ""
    return rows

@app.get("/api/threats/{tid}")
def threat(tid: int, u=Depends(viewer)):
    t = q("SELECT * FROM threats WHERE id=?", (tid,), one=True)
    if not t: raise HTTPException(404, "Threat not found")
    try: t["detail"] = json.loads(t["detail"])
    except (TypeError, ValueError): pass
    return t

class ThreatPatch(BaseModel):
    status: Optional[str] = None; assignee: Optional[str] = Field(default=None, max_length=64); notes: Optional[str] = Field(default=None, max_length=4000)

@app.patch("/api/threats/{tid}")
def patch_threat(tid: int, b: ThreatPatch, u=Depends(analyst)):
    t = q("SELECT * FROM threats WHERE id=?", (tid,), one=True)
    if not t: raise HTTPException(404, "Threat not found")
    if b.status is not None:
        if b.status not in db.STATUSES: raise HTTPException(422, "Invalid status")
        q("UPDATE threats SET status=? WHERE id=?", (b.status, tid)); db.activity(f"{u['username']} set status {b.status}: {t['name']}", t["device"], "Analyst action")
    if b.assignee is not None: q("UPDATE threats SET assignee=? WHERE id=?", (b.assignee, tid))
    if b.notes is not None: q("UPDATE threats SET notes=? WHERE id=?", (b.notes, tid))
    core.publish({"type": "update"}); return {"ok": True}

@app.get("/api/events")
def events(kind: Optional[str] = None, device: Optional[str] = None, qs: Optional[str] = Query(None, alias="q"),
           before_id: Optional[int] = None, limit: int = Query(100, ge=1, le=200), u=Depends(viewer)):
    where, args = [], []
    if kind: where.append("kind=?"); args.append(kind)
    if device: where.append("device=? COLLATE NOCASE"); args.append(device)
    if before_id: where.append("id<?"); args.append(before_id)
    if qs: where.append("data LIKE ? ESCAPE '\\'"); args.append("%" + qs.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
    rows = q("SELECT * FROM events" + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY id DESC LIMIT ?", (*args, limit))
    for r in rows: r["data"] = json.loads(r["data"])
    return rows

@app.get("/api/activity")
def activity(limit: int = Query(50, ge=1, le=200), u=Depends(viewer)):
    return q("SELECT ts,level,text,device,origin FROM activity ORDER BY ts DESC, id DESC LIMIT ?", (limit,))

@app.get("/api/audit")
def audit_log(limit: int = Query(100, ge=1, le=500), u=Depends(admin)):
    return q("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,))

@app.get("/api/traffic")
def traffic(seconds: int = Query(60, ge=10, le=86400), u=Depends(viewer)):
    now = time.time(); step = max(1, seconds // 60)
    rows = q("""SELECT b*? AS t, SUM(i) AS inbound, SUM(o) AS outbound FROM
                (SELECT CAST(ts/? AS INTEGER) b, source, AVG(inbound) i, AVG(outbound) o FROM traffic WHERE ts>? GROUP BY b, source)
                GROUP BY b ORDER BY b""", (step, step, now - seconds))
    return {"now": now, "seconds": seconds, "points": rows}

@app.get("/api/alerts")
def alerts(u=Depends(viewer)):
    return q("SELECT id,ts,severity,name,device,alert_state FROM threats WHERE alert_state<2 ORDER BY ts DESC LIMIT 50")

@app.post("/api/alerts/read")
def alerts_read(u=Depends(analyst)):
    q("UPDATE threats SET alert_state=1 WHERE alert_state=0"); core.publish({"type": "update"}); return {"ok": True}

@app.delete("/api/alerts")
def alerts_clear(u=Depends(analyst)):          # clears the alert centre only; detections are kept
    q("UPDATE threats SET alert_state=2 WHERE alert_state<2"); core.publish({"type": "update"}); return {"ok": True}

@app.get("/api/stream")
async def stream(u=Depends(viewer)):
    qu = asyncio.Queue(maxsize=100); core._subs.add(qu)
    async def gen():
        try:
            yield "retry: 3000\n\n"
            while True:
                try: yield f"data: {json.dumps(await asyncio.wait_for(qu.get(), 15))}\n\n"
                except asyncio.TimeoutError: yield ": keepalive\n\n"
        finally: core._subs.discard(qu)
    return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache"})

# ---------------- demo mode (drives the real pipeline with synthetic telemetry) ----------------
DEMO_DEVICES = [("WORKSTATION-01", "Windows 11", "192.168.1.12"), ("WAZUH-SERVER", "Linux", "192.168.1.33"),
                ("FINANCE-PC-02", "Windows 10", "192.168.1.24"), ("NAS-STORAGE", "Linux", "192.168.1.50"),
                ("HR-PC-01", "Windows 11", "192.168.1.15"), ("BACKUP-SRV", "Linux", "192.168.1.41"),
                ("DEV-LAPTOP-03", "macOS", "192.168.1.62"), ("GATEWAY", "Linux", "192.168.1.1")]
DEMO_DST = ["192.168.1.33", "185.199.110.22", "93.184.216.34", "140.82.112.3", "203.0.113.45"]

def _demo_report(host, os_, ip, events=()):
    return ReportIn(os=os_, ip=ip, version="demo", events=list(events),
                    metrics={"cpu_percent": random.uniform(5, 60), "mem_percent": random.uniform(30, 75), "disk_percent": random.uniform(40, 70)},
                    traffic={"inbound_mbps": random.uniform(2, 12), "outbound_mbps": random.uniform(0.5, 5)})

async def demo_loop():
    if not db.get_setting("blocklist"): db.set_settings({"blocklist": ["203.0.113.0/24"]})
    first = True
    while True:
        for h, o, ip in DEMO_DEVICES:
            if h == "NAS-STORAGE" and first:
                core.touch_device(h, o, ip); q("UPDATE devices SET last_seen=? WHERE hostname=?", (time.time() - 3600, h)); continue
            if h == "NAS-STORAGE": continue
            ev = [{"kind": "connection", "dst_ip": random.choice(DEMO_DST[:4]), "dst_port": 443, "process": "chrome"}] if random.random() < .3 else []
            core.process_report(h, _demo_report(h, o, ip, ev))
        first = False
        await asyncio.sleep(5)

@app.post("/api/dev/simulate")
def simulate(u=Depends(analyst)):
    if not db.DEMO: raise HTTPException(404, "Simulation is only available in demo mode (CROWS_EYE_DEMO=1)")
    k = random.choice(("brute", "ps", "conn"))
    if k == "brute":
        src = f"192.168.1.{random.randint(60, 99)}"
        evs = [{"kind": "auth_failure", "src_ip": src, "user": "root", "service": "sshd"}] * 5; host = "WAZUH-SERVER"
    elif k == "ps":
        evs = [{"kind": "process_start", "process": "powershell.exe", "cmdline": "powershell.exe -nop -enc SQBFAFgA", "user": "finance"}]; host = "FINANCE-PC-02"
    else:
        evs = [{"kind": "connection", "dst_ip": "203.0.113.45", "dst_port": 4444, "process": "svchost.exe"}]; host = "WORKSTATION-01"
    d = next(x for x in DEMO_DEVICES if x[0] == host)
    return core.process_report(host, _demo_report(*d, evs))

app.mount("/", StaticFiles(directory=Path(__file__).resolve().parent.parent / "static", html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=os.getenv("CROWS_EYE_HOST", "127.0.0.1"), port=int(os.getenv("CROWS_EYE_PORT", 8000)))
