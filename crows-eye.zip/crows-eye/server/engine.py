"""Detection rule engine + notifications (webhook / email)."""
import collections, ipaddress, json, os, queue, re, smtplib, threading, time, urllib.request
from email.message import EmailMessage
from functools import lru_cache
from . import db

KINDS = ("auth_failure", "auth_success", "process_start", "connection", "listening_port", "metric", "custom")
OPS = ("eq", "ne", "contains", "regex", "gt", "gte", "lt", "lte", "in", "is_private", "in_blocklist")

DEFAULT_RULES = [
    ("Repeated failed login attempts", "CRITICAL", "auth_failure", [], {"count": 5, "window": 60, "group_by": "src_ip"}, 300),
    ("Suspicious PowerShell activity", "HIGH", "process_start",
     [{"field": "cmdline", "op": "regex", "value": r"(?i)powershell.*(-enc\b|-encodedcommand|downloadstring|invoke-expression|\biex\b|-nop.*bypass)"}], None, 300),
    ("Connection to blocklisted address", "HIGH", "connection", [{"field": "dst_ip", "op": "in_blocklist", "value": True}], None, 600),
    ("New listening port", "MEDIUM", "listening_port", [{"field": "new", "op": "eq", "value": "true"}], None, 3600),
    ("Disk almost full", "MEDIUM", "metric", [{"field": "disk_percent", "op": "gte", "value": 95}], None, 3600),
]

# ---------------- rule storage / cache ----------------
_rules: list = []; _rlock = threading.Lock()
def reload_rules():
    rows = db.q("SELECT * FROM rules ORDER BY id")
    for r in rows: r["match"] = json.loads(r["match"] or "[]"); r["threshold"] = json.loads(r["threshold"] or "null")
    with _rlock: _rules[:] = rows

def seed_rules():
    if db.q("SELECT COUNT(*) n FROM rules", one=True)["n"] == 0:
        for n, s, k, m, t, c in DEFAULT_RULES:
            db.q("INSERT INTO rules(name,severity,kind,match,threshold,cooldown,builtin) VALUES(?,?,?,?,?,?,1)",
                 (n, s, k, json.dumps(m), json.dumps(t), c))
    reload_rules()

def validate_rule(r: dict):
    """Returns an error string or None."""
    if r["severity"] not in db.SEVERITIES: return "Invalid severity"
    if r["kind"] not in KINDS: return "Invalid kind"
    if not (0 <= r["cooldown"] <= 86400): return "Cooldown must be 0-86400 seconds"
    for c in r["match"]:
        if c.get("op") not in OPS or not str(c.get("field", "")).strip(): return "Invalid condition"
        if c["op"] == "regex":
            if len(str(c.get("value", ""))) > 300: return "Regex too long"
            try: re.compile(str(c["value"]))
            except re.error as e: return f"Bad regex: {e}"
    t = r.get("threshold")
    if t and not (1 <= int(t.get("count", 0)) <= 10000 and 1 <= int(t.get("window", 0)) <= 86400): return "Threshold out of range"
    return None

# ---------------- matching ----------------
@lru_cache(maxsize=256)
def _rx(p): return re.compile(p)

_bl = (None, [])
def _blocklist():
    global _bl
    raw = db.get_setting("blocklist")
    if _bl[0] is not raw:
        nets = []
        for x in raw:
            try: nets.append(ipaddress.ip_network(str(x).strip(), strict=False))
            except ValueError: pass
        _bl = (raw, nets)
    return _bl[1]

def _num(x):
    try: return float(x)
    except (TypeError, ValueError): return None

def cond_match(c, ev) -> bool:
    v, op, t = ev.get(c["field"]), c["op"], c.get("value")
    if op in ("is_private", "in_blocklist"):
        try: ip = ipaddress.ip_address(str(v))
        except ValueError: return False
        res = ip.is_private if op == "is_private" else any(ip in n for n in _blocklist())
        return res == (t is not False)
    if v is None: return False
    sv, st = str(v).lower(), str(t).lower()
    if op == "eq": return sv == st
    if op == "ne": return sv != st
    if op == "contains": return st in sv
    if op == "regex": return bool(_rx(str(t)).search(str(v)))
    if op == "in": return sv in [str(x).lower() for x in (t if isinstance(t, list) else [t])]
    a, b = _num(v), _num(t)
    if a is None or b is None: return False
    return {"gt": a > b, "gte": a >= b, "lt": a < b, "lte": a <= b}[op]

# ---------------- evaluation ----------------
_hits = collections.defaultdict(collections.deque); _fired = {}; _elock = threading.Lock()

def evaluate(ev: dict) -> list:
    """ev has kind, device, ts + data fields. Returns [(rule, group, evidence_events)] for rules that fire."""
    out = []
    with _rlock: rules = list(_rules)
    for r in rules:
        if not r["enabled"] or r["kind"] != ev["kind"]: continue
        try:
            if not all(cond_match(c, ev) for c in r["match"]): continue
        except Exception: continue
        th, now = r["threshold"], ev["ts"]
        group = str(ev.get(th["group_by"]) or ev["device"]) if th and th.get("group_by") else ev["device"]
        gk = (r["id"], group)
        with _elock:
            if th:
                dq = _hits[gk]; dq.append((now, ev))
                while dq and dq[0][0] < now - th["window"]: dq.popleft()
                if len(dq) < th["count"]: continue
                evidence = [e for _, e in dq][-10:]
            else:
                evidence = [ev]
            if now - _fired.get(gk, 0) < r["cooldown"]: continue
            _fired[gk] = now
            if th: _hits[gk].clear()
        out.append((r, group, evidence))
    return out

def prune_state():
    now = time.time()
    with _elock:
        for k in [k for k, d in _hits.items() if not d or d[-1][0] < now - 86400]: _hits.pop(k, None)
        for k in [k for k, t in _fired.items() if t < now - 86400]: _fired.pop(k, None)

# ---------------- notifications ----------------
_nq: queue.Queue = queue.Queue(maxsize=200)
def _rank(s): return db.SEVERITIES.index(s)

def notify(threat: dict):
    s = db.all_settings()
    wh = s["webhook_url"] and _rank(threat["severity"]) >= _rank(s["webhook_min_severity"])
    em = s["email_enabled"] and _rank(threat["severity"]) >= _rank(s["email_min_severity"])
    if wh or em:
        try: _nq.put_nowait(threat)
        except queue.Full: pass

def _text(t): return f"[Crow's Eye] {t['severity']}: {t['name']} on {t['device']} (source {t['source']})"

def send_webhook(url, threat):
    if not url.startswith(("http://", "https://")): raise ValueError("Webhook URL must be http(s)")
    body = json.dumps({"text": _text(threat), "threat": {k: threat[k] for k in ("id", "severity", "name", "source", "device", "ts")}}).encode()
    urllib.request.urlopen(urllib.request.Request(url, body, {"Content-Type": "application/json"}), timeout=5).read()

def send_email(s, threat):
    if not (s["smtp_host"] and s["email_to"]): raise ValueError("SMTP host and recipient required")
    m = EmailMessage(); m["Subject"] = _text(threat)[:200]; m["From"] = s["smtp_from"] or s["smtp_user"]; m["To"] = s["email_to"]
    m.set_content(f"{_text(threat)}\n\nStatus: {threat['status']}\nTime: {time.ctime(threat['ts'])}\n")
    with smtplib.SMTP(s["smtp_host"], int(s["smtp_port"]), timeout=10) as c:
        c.starttls()
        if s["smtp_user"]: c.login(s["smtp_user"], os.getenv("CROWS_EYE_SMTP_PASSWORD", ""))
        c.send_message(m)

def _worker():
    while True:
        t = _nq.get(); s = db.all_settings()
        for name, cond, fn in (("webhook", s["webhook_url"] and _rank(t["severity"]) >= _rank(s["webhook_min_severity"]), lambda: send_webhook(s["webhook_url"], t)),
                               ("email", s["email_enabled"] and _rank(t["severity"]) >= _rank(s["email_min_severity"]), lambda: send_email(s, t))):
            if cond:
                try: fn()
                except Exception as e: db.activity(f"Notification via {name} failed: {e}", t["device"], "Notifier", "MEDIUM")

def start_worker(): threading.Thread(target=_worker, daemon=True, name="notifier").start()
