"""Password hashing, sessions + CSRF, role checks, API-key auth, login throttling."""
import hashlib, hmac, os, secrets, threading, time
from fastapi import HTTPException, Header, Request
from . import db

ROLES = {"viewer": 1, "analyst": 2, "admin": 3}
COOKIE, SESSION_TTL = "ce_session", 12 * 3600
SECURE_COOKIES = os.getenv("CROWS_EYE_SECURE_COOKIES") == "1"
TRUST_PROXY = os.getenv("CROWS_EYE_TRUST_PROXY") == "1"

sha = lambda s: hashlib.sha256(s.encode()).hexdigest()

def hash_pw(pw: str) -> str:
    salt = os.urandom(16)
    return f"scrypt${salt.hex()}${hashlib.scrypt(pw.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32).hex()}"

def check_pw(pw: str, stored: str) -> bool:
    try:
        _, salt, h = stored.split("$")
        got = hashlib.scrypt(pw.encode(), salt=bytes.fromhex(salt), n=2**14, r=8, p=1, dklen=32)
        return hmac.compare_digest(got.hex(), h)
    except Exception:
        return False

def valid_password(pw: str):
    if len(pw) < 10: raise HTTPException(422, "Password must be at least 10 characters")

def create_session(user_id: int):
    token, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(24)
    db.q("DELETE FROM sessions WHERE expires<?", (time.time(),))
    db.q("INSERT INTO sessions VALUES(?,?,?,?)", (sha(token), user_id, csrf, time.time() + SESSION_TTL))
    return token, csrf

def current_user(request: Request):
    token = request.cookies.get(COOKIE)
    if not token: return None
    return db.q("""SELECT u.id,u.username,u.role,s.csrf FROM sessions s JOIN users u ON u.id=s.user_id
                   WHERE s.token_hash=? AND s.expires>? AND u.disabled=0""", (sha(token), time.time()), one=True)

def need(role: str):
    """FastAPI dependency: requires a session with at least `role`; mutating calls need the CSRF header."""
    def dep(request: Request):
        u = current_user(request)
        if not u: raise HTTPException(401, "Not authenticated")
        if ROLES[u["role"]] < ROLES[role]: raise HTTPException(403, "Insufficient role")
        if request.method not in ("GET", "HEAD", "OPTIONS") and not hmac.compare_digest(
                request.headers.get("x-csrf-token", ""), u["csrf"]):
            raise HTTPException(403, "Bad CSRF token")
        return u
    return dep

def key_auth(kind: str):
    """FastAPI dependency: validates X-API-Key for a key of the given kind."""
    def dep(x_api_key: str = Header(default="")):
        row = db.q("SELECT * FROM api_keys WHERE key_hash=? AND revoked=0 AND kind=?", (sha(x_api_key), kind), one=True)
        if not row: raise HTTPException(401, "Invalid or revoked API key")
        if time.time() - row["last_used"] > 60: db.q("UPDATE api_keys SET last_used=? WHERE id=?", (time.time(), row["id"]))
        return row
    return dep

def new_key(name, kind, hostname=None):
    key = "ce_" + secrets.token_urlsafe(32)
    kid = db.insert("INSERT INTO api_keys(name,kind,key_hash,hostname,created) VALUES(?,?,?,?,?)",
                    (name, kind, sha(key), hostname, time.time()))
    return kid, key

# ---- login throttling: 5 failures / 5 min per (ip, username) ----
_fails: dict = {}; _flock = threading.Lock()
def client_ip(request: Request):
    if TRUST_PROXY and request.headers.get("x-forwarded-for"):
        return request.headers["x-forwarded-for"].split(",")[-1].strip()
    return request.client.host if request.client else "?"

def throttled(key) -> bool:
    with _flock:
        v = [t for t in _fails.get(key, []) if t > time.time() - 300]; _fails[key] = v
        return len(v) >= 5
def record_fail(key):
    with _flock: _fails.setdefault(key, []).append(time.time())
def clear_fails(key):
    with _flock: _fails.pop(key, None)
