"""Configuration, SQLite storage, settings, audit log."""
import json, os, sqlite3, threading, time
from pathlib import Path

DATA_DIR = Path(os.getenv("CROWS_EYE_DATA", Path(__file__).resolve().parent.parent / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DEMO = os.getenv("CROWS_EYE_DEMO") == "1"
SEVERITIES = ("LOW", "MEDIUM", "HIGH", "CRITICAL")           # ascending order
OPEN_STATES = ("New", "Investigate", "Open", "Review")
STATUSES = OPEN_STATES + ("Monitoring", "Resolved")
DEFAULT_STATUS = {"CRITICAL": "Investigate", "HIGH": "Open", "MEDIUM": "Review", "LOW": "Monitoring"}

_db = sqlite3.connect(os.getenv("CROWS_EYE_DB", str(DATA_DIR / "crows_eye.db")), check_same_thread=False)
_db.row_factory = sqlite3.Row
lock = threading.RLock()
with lock:
    _db.executescript("""
    PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE COLLATE NOCASE NOT NULL,
        pw_hash TEXT NOT NULL, role TEXT NOT NULL, disabled INTEGER DEFAULT 0, created REAL);
    CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        csrf TEXT, expires REAL);
    CREATE TABLE IF NOT EXISTS api_keys(id INTEGER PRIMARY KEY, name TEXT, kind TEXT, key_hash TEXT UNIQUE,
        hostname TEXT, created REAL, last_used REAL DEFAULT 0, revoked INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS devices(id INTEGER PRIMARY KEY, hostname TEXT UNIQUE COLLATE NOCASE, os TEXT, ip TEXT,
        version TEXT, last_seen REAL, offline_flagged INTEGER DEFAULT 0, cpu REAL, mem REAL, disk REAL);
    CREATE TABLE IF NOT EXISTS metrics(ts REAL, device TEXT, cpu REAL, mem REAL, disk REAL);
    CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, ts REAL, device TEXT, kind TEXT, data TEXT);
    CREATE TABLE IF NOT EXISTS threats(id INTEGER PRIMARY KEY, ts REAL, severity TEXT, name TEXT, source TEXT, device TEXT,
        detail TEXT, status TEXT, assignee TEXT DEFAULT '', notes TEXT DEFAULT '', rule_id INTEGER, alert_state INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS rules(id INTEGER PRIMARY KEY, name TEXT, enabled INTEGER DEFAULT 1, severity TEXT, kind TEXT,
        match TEXT, threshold TEXT, cooldown INTEGER DEFAULT 300, builtin INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS traffic(ts REAL, source TEXT, inbound REAL, outbound REAL);
    CREATE TABLE IF NOT EXISTS activity(id INTEGER PRIMARY KEY, ts REAL, level TEXT, text TEXT, device TEXT, origin TEXT);
    CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, ts REAL, user TEXT, action TEXT, detail TEXT);
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
    CREATE INDEX IF NOT EXISTS i_ev ON events(ts); CREATE INDEX IF NOT EXISTS i_ev_dk ON events(device, kind, ts);
    CREATE INDEX IF NOT EXISTS i_th ON threats(ts); CREATE INDEX IF NOT EXISTS i_tr ON traffic(ts);
    CREATE INDEX IF NOT EXISTS i_me ON metrics(device, ts);
    """)

def q(sql, args=(), one=False):
    with lock:
        rows = _db.execute(sql, args).fetchall(); _db.commit()
    return (dict(rows[0]) if rows else None) if one else [dict(r) for r in rows]

def insert(sql, args=()):
    with lock:
        cur = _db.execute(sql, args); _db.commit(); return cur.lastrowid

def many(sql, rows):
    with lock:
        _db.executemany(sql, rows); _db.commit()

# ---- settings (JSON values, cached) ----
DEFAULTS = {"offline_after": 90, "retention_days": 7, "blocklist": [],
            "webhook_url": "", "webhook_min_severity": "HIGH",
            "email_enabled": False, "email_min_severity": "CRITICAL", "smtp_host": "", "smtp_port": 587,
            "smtp_user": "", "smtp_from": "", "email_to": ""}   # SMTP password: env CROWS_EYE_SMTP_PASSWORD only
_cache: dict = {}
def _load():
    _cache.clear(); _cache.update(DEFAULTS)
    for r in q("SELECT key,value FROM settings"):
        if r["key"] in DEFAULTS: _cache[r["key"]] = json.loads(r["value"])
_load()
def get_setting(k): return _cache[k]
def all_settings(): return dict(_cache)
def set_settings(d):
    for k, v in d.items():
        if k in DEFAULTS: q("INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, json.dumps(v)))
    _load()

def audit(user, action, detail=""):
    q("INSERT INTO audit(ts,user,action,detail) VALUES(?,?,?,?)", (time.time(), user, action, detail[:500]))

def activity(text, device="", origin="", level=""):
    q("INSERT INTO activity(ts,level,text,device,origin) VALUES(?,?,?,?,?)", (time.time(), level, text[:300], device, origin))
