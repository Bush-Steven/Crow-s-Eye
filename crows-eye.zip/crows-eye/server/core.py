"""Pipeline: agent report -> events -> rules -> threats; plus overview/network queries and housekeeping."""
import asyncio, json, time
from . import db, engine
from .db import q

# ---- live events (SSE) ----
_subs: set = set(); _loop = None
def set_loop(loop):
    global _loop; _loop = loop
def publish(ev: dict):
    """Never let a closed/absent event loop break ingestion."""
    if _loop and not _loop.is_closed():
        try: _loop.call_soon_threadsafe(_fanout, ev)
        except RuntimeError: pass
def _fanout(ev):
    for qu in list(_subs):
        try: qu.put_nowait(ev)
        except asyncio.QueueFull: pass

OPENQ = f"status IN ({','.join('?' * len(db.OPEN_STATES))})"

# ---- threats ----
def add_threat(severity, name, source, device, detail="", rule_id=None, ts=None):
    sev = severity.upper()
    tid = db.insert("INSERT INTO threats(ts,severity,name,source,device,detail,status,rule_id) VALUES(?,?,?,?,?,?,?,?)",
                    (ts or time.time(), sev, name[:200], str(source)[:200], device[:100], detail[:6000], db.DEFAULT_STATUS[sev], rule_id))
    db.activity(name, device, "Detection", sev)
    t = q("SELECT * FROM threats WHERE id=?", (tid,), one=True)
    publish({"type": "threat", "threat": t}); engine.notify(t); return t

# ---- devices ----
def touch_device(hostname, os_=None, ip=None, version=None, m=None):
    m = m or {}
    row = q("SELECT * FROM devices WHERE hostname=?", (hostname,), one=True)
    now = time.time()
    if row is None:
        q("INSERT INTO devices(hostname,os,ip,version,last_seen,cpu,mem,disk) VALUES(?,?,?,?,?,?,?,?)",
          (hostname, os_ or "", ip or "", version or "", now, m.get("cpu_percent"), m.get("mem_percent"), m.get("disk_percent")))
        db.activity("New endpoint registered", hostname, "Agent registry")
    else:
        q("""UPDATE devices SET last_seen=?, os=COALESCE(?,os), ip=COALESCE(?,ip), version=COALESCE(?,version), offline_flagged=0,
             cpu=COALESCE(?,cpu), mem=COALESCE(?,mem), disk=COALESCE(?,disk) WHERE id=?""",
          (now, os_, ip, version, m.get("cpu_percent"), m.get("mem_percent"), m.get("disk_percent"), row["id"]))
        if row["offline_flagged"]: db.activity("Endpoint back online", hostname, "Agent monitor")
    if m: q("INSERT INTO metrics VALUES(?,?,?,?,?)", (now, hostname, m.get("cpu_percent"), m.get("mem_percent"), m.get("disk_percent")))
    publish({"type": "device"})

def _clean(d: dict) -> dict:
    out = {}
    for k, v in list(d.items())[:30]:
        if isinstance(v, (bool, int, float)): out[str(k)[:40]] = v
        elif isinstance(v, str): out[str(k)[:40]] = v[:2000]
    return out

def process_report(hostname: str, rep) -> dict:
    """rep: ReportIn. `hostname` comes from the API key, never from the payload."""
    m = {k: v for k, v in (rep.metrics or {}).items() if isinstance(v, (int, float)) and k in ("cpu_percent", "mem_percent", "disk_percent")}
    touch_device(hostname, rep.os, rep.ip, rep.version, m)
    now = time.time()
    if rep.traffic:
        q("INSERT INTO traffic VALUES(?,?,?,?)", (now, hostname, max(0.0, rep.traffic.get("inbound_mbps", 0)), max(0.0, rep.traffic.get("outbound_mbps", 0))))
    evs, rows, fired = [], [], []
    for e in rep.events[:500]:
        kind = e.get("kind") if e.get("kind") in engine.KINDS else "custom"
        data = _clean({k: v for k, v in e.items() if k != "kind"})
        rows.append((now, hostname, kind, json.dumps(data)))
        evs.append({**data, "kind": kind, "device": hostname, "ts": now})
    if rows: db.many("INSERT INTO events(ts,device,kind,data) VALUES(?,?,?,?)", rows)
    if m: evs.append({**m, "kind": "metric", "device": hostname, "ts": now})
    for ev in evs:
        for rule, group, evidence in engine.evaluate(ev):
            src = ev.get("src_ip") or ev.get("dst_ip") or ev.get("process") or group
            fired.append(add_threat(rule["severity"], rule["name"], src, hostname,
                                    json.dumps({"rule": rule["name"], "group": group, "events": evidence}), rule["id"]))
    if rows: publish({"type": "events"})
    return {"accepted": len(rows), "threats": len(fired)}

# ---- overview ----
def overview():
    now, off = time.time(), db.get_setting("offline_after")
    devs = q("SELECT last_seen FROM devices"); online = sum(1 for d in devs if now - d["last_seen"] <= off)
    cnt = lambda sev: q(f"SELECT COUNT(*) n FROM threats WHERE severity=? AND {OPENQ}", (sev, *db.OPEN_STATES), one=True)["n"]
    base = 100 * online / len(devs) if devs else 100
    tr = q("""SELECT inbound,outbound FROM traffic t WHERE ts>? AND ts=(SELECT MAX(ts) FROM traffic WHERE source=t.source)""", (now - 30,))
    return {"demo": db.DEMO,
            "endpoints": {"total": len(devs), "online": online, "offline": len(devs) - online},
            "threats": {"total": q("SELECT COUNT(*) n FROM threats", one=True)["n"],
                        "needs_investigation": q(f"SELECT COUNT(*) n FROM threats WHERE {OPENQ}", db.OPEN_STATES, one=True)["n"]},
            "traffic": {"inbound_mbps": sum(r["inbound"] for r in tr), "outbound_mbps": sum(r["outbound"] for r in tr),
                        "total_mbps": sum(r["inbound"] + r["outbound"] for r in tr)},
            # health = % of endpoints reporting, minus 5 per open critical and 2 per open high detection
            "health": max(0, round(base - 5 * cnt("CRITICAL") - 2 * cnt("HIGH"))),
            "alerts_unread": q("SELECT COUNT(*) n FROM threats WHERE alert_state=0", one=True)["n"]}

def devices():
    now, off = time.time(), db.get_setting("offline_after")
    warn = {r["d"] for r in q(f"SELECT DISTINCT lower(device) d FROM threats WHERE severity IN ('CRITICAL','HIGH') AND {OPENQ}", db.OPEN_STATES)}
    out = []
    for d in q("SELECT hostname,os,ip,version,last_seen,cpu,mem,disk FROM devices ORDER BY hostname"):
        d["status"] = "offline" if now - d["last_seen"] > off else "warning" if d["hostname"].lower() in warn else "online"
        out.append(d)
    return out

def network(minutes=15):
    since = time.time() - minutes * 60
    rows = q("""SELECT device, json_extract(data,'$.dst_ip') ip, COUNT(*) n FROM events
                WHERE kind='connection' AND ts>? AND ip IS NOT NULL GROUP BY device, ip ORDER BY n DESC LIMIT 300""", (since,))
    for r in rows:
        r["blocklisted"] = bool(engine.cond_match({"field": "ip", "op": "in_blocklist", "value": True}, {"ip": r["ip"]}))
        try:
            import ipaddress; r["private"] = ipaddress.ip_address(r["ip"]).is_private
        except ValueError: r["private"] = False
    return {"devices": devices(), "edges": rows}

# ---- housekeeping ----
def check_offline():
    now = time.time()
    for d in q("SELECT * FROM devices WHERE last_seen<? AND offline_flagged=0", (now - db.get_setting("offline_after"),)):
        q("UPDATE devices SET offline_flagged=1 WHERE id=?", (d["id"],))
        add_threat("LOW", "Endpoint agent heartbeat delayed", "Agent monitor", d["hostname"])

def retention():
    now, days = time.time(), db.get_setting("retention_days")
    q("DELETE FROM events WHERE ts<?", (now - days * 86400,))
    q("DELETE FROM traffic WHERE ts<?", (now - 2 * 86400,)); q("DELETE FROM metrics WHERE ts<?", (now - 2 * 86400,))
    q("DELETE FROM activity WHERE ts<?", (now - 30 * 86400,)); q("DELETE FROM threats WHERE ts<?", (now - 365 * 86400,))
    engine.prune_state()

async def housekeeping():
    n = 0
    while True:
        await asyncio.sleep(10); n += 1
        await asyncio.to_thread(check_offline)
        if n % 60 == 1: await asyncio.to_thread(retention)
