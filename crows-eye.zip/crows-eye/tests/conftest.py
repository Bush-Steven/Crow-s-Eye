import os, sys, tempfile
d = tempfile.mkdtemp()
os.environ.update(CROWS_EYE_DATA=d, CROWS_EYE_DB=os.path.join(d, "t.db"), CROWS_EYE_ADMIN_PASSWORD="correct-horse-battery")
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
