import pytest
from fastapi.testclient import TestClient
from server.main import app

def login(c, user="admin", pw="correct-horse-battery"):
    r = c.post("/api/auth/login", json={"username": user, "password": pw})
    assert r.status_code == 200, r.text
    c.headers["X-CSRF-Token"] = r.json()["csrf"]; return r.json()

@pytest.fixture(scope="module")
def admin():
    with TestClient(app) as c:
        login(c); yield c

def agent_key(admin, host):
    return admin.post("/api/keys", json={"name": host, "kind": "agent", "hostname": host}).json()["key"]

def report(c, key, events=(), **kw):
    return c.post("/api/agent/report", headers={"X-API-Key": key}, json={"events": list(events), **kw})

def test_requires_auth():
    with TestClient(app) as c:
        assert c.get("/api/overview").status_code == 401
        assert c.get("/api/stream").status_code == 401
        assert c.get("/healthz").status_code == 200

def test_login_logout_and_csrf(admin):
    assert admin.get("/api/auth/me").json()["role"] == "admin"
    bad = TestClient(app); bad.cookies.update(admin.cookies)              # cookie but no CSRF header
    assert bad.patch("/api/threats/1", json={"status": "Open"}).status_code == 403
    assert bad.post("/api/keys", json={"name": "x", "kind": "agent", "hostname": "h"}).status_code == 403

def test_login_throttle():
    with TestClient(app) as c:
        codes = [c.post("/api/auth/login", json={"username": "nobody", "password": "x"}).status_code for _ in range(7)]
        assert codes[:5] == [401] * 5 and codes[5:] == [429, 429]

def test_roles(admin):
    assert admin.post("/api/users", json={"username": "vera", "password": "viewer-password-1", "role": "viewer"}).status_code == 200
    with TestClient(app) as v:
        login(v, "vera", "viewer-password-1")
        assert v.get("/api/overview").status_code == 200
        assert v.get("/api/settings").status_code == 403
        assert v.post("/api/rules", json={}).status_code in (403, 422)
        assert v.patch("/api/threats/1", json={"status": "Open"}).status_code == 403

def test_last_admin_protected(admin):
    uid = next(u["id"] for u in admin.get("/api/users").json() if u["username"] == "admin")
    assert admin.patch(f"/api/users/{uid}", json={"role": "viewer"}).status_code == 409
    assert admin.delete(f"/api/users/{uid}").status_code == 409

def test_password_policy(admin):
    assert admin.post("/api/users", json={"username": "weak", "password": "short", "role": "viewer"}).status_code == 422

def test_agent_key_auth_and_binding(admin):
    key = agent_key(admin, "HOST-A")
    assert report(admin, "bogus").status_code == 401
    assert report(admin, key, metrics={"cpu_percent": 10, "mem_percent": 20, "disk_percent": 30}, os="Linux", ip="10.0.0.5").status_code == 200
    assert any(d["hostname"] == "HOST-A" and d["status"] == "online" for d in admin.get("/api/devices").json())
    # an agent key can't use integration endpoints
    assert admin.post("/api/ingest/wazuh", headers={"X-API-Key": key}, json={}).status_code == 401
    # a payload cannot spoof another hostname: events are attributed to the key's device
    report(admin, key, [{"kind": "custom", "device": "HOST-B", "msg": "x"}])
    ev = admin.get("/api/events", params={"kind": "custom"}).json()
    assert ev and all(e["device"] == "HOST-A" for e in ev)

def test_brute_force_threshold_and_cooldown(admin):
    key = agent_key(admin, "HOST-BF")
    fail = {"kind": "auth_failure", "src_ip": "203.0.113.9", "user": "root"}
    assert report(admin, key, [fail] * 4).json()["threats"] == 0
    assert report(admin, key, [fail]).json()["threats"] == 1                  # 5th failure within 60s fires
    assert report(admin, key, [fail] * 10).json()["threats"] == 0             # cooldown suppresses repeats
    t = admin.get("/api/threats", params={"device": "HOST-BF"}).json()
    assert t[0]["severity"] == "CRITICAL" and t[0]["source"] == "203.0.113.9"
    assert "events" in admin.get(f"/api/threats/{t[0]['id']}").json()["detail"]

def test_powershell_and_blocklist_rules(admin):
    key = agent_key(admin, "HOST-PS")
    ps = {"kind": "process_start", "process": "powershell.exe", "cmdline": "powershell -nop -w hidden -enc SQBFAFgA"}
    ok = {"kind": "process_start", "process": "powershell.exe", "cmdline": "powershell Get-Date"}
    assert report(admin, key, [ok]).json()["threats"] == 0
    assert report(admin, key, [ps]).json()["threats"] == 1
    conn = {"kind": "connection", "dst_ip": "198.51.100.7", "dst_port": 443, "process": "curl"}
    assert report(admin, key, [conn]).json()["threats"] == 0
    assert admin.put("/api/settings", json={"blocklist": ["198.51.100.0/24"]}).status_code == 200
    assert report(admin, key, [conn]).json()["threats"] == 1
    net = admin.get("/api/network").json()
    assert any(e["ip"] == "198.51.100.7" and e["blocklisted"] for e in net["edges"])

def test_metric_rule_and_listening_port(admin):
    key = agent_key(admin, "HOST-M")
    assert report(admin, key, metrics={"cpu_percent": 1, "mem_percent": 1, "disk_percent": 97}).json()["threats"] == 1
    assert report(admin, key, [{"kind": "listening_port", "port": 4444, "new": False}]).json()["threats"] == 0
    assert report(admin, key, [{"kind": "listening_port", "port": 4444, "new": True}]).json()["threats"] == 1

def test_rule_crud_and_validation(admin):
    base = {"name": "t", "severity": "LOW", "kind": "custom", "match": [{"field": "msg", "op": "contains", "value": "boom"}]}
    assert admin.post("/api/rules", json={**base, "match": [{"field": "m", "op": "regex", "value": "("}]}).status_code == 422
    assert admin.post("/api/rules", json={**base, "severity": "NOPE"}).status_code == 422
    assert admin.post("/api/rules", json={**base, "threshold": {"count": 0, "window": 5}}).status_code == 422
    rid = admin.post("/api/rules", json=base).json()["id"]
    key = agent_key(admin, "HOST-R")
    assert report(admin, key, [{"kind": "custom", "msg": "big BOOM"}]).json()["threats"] == 1
    admin.put(f"/api/rules/{rid}", json={**base, "enabled": False})
    assert report(admin, key, [{"kind": "custom", "msg": "boom again"}]).json()["threats"] == 0
    assert admin.delete(f"/api/rules/{rid}").status_code == 200

def test_threat_workflow(admin):
    t = admin.get("/api/threats").json()[0]
    assert admin.patch(f"/api/threats/{t['id']}", json={"status": "Resolved", "assignee": "admin", "notes": "ok"}).status_code == 200
    got = admin.get(f"/api/threats/{t['id']}").json()
    assert (got["status"], got["assignee"], got["notes"]) == ("Resolved", "admin", "ok")
    assert admin.patch(f"/api/threats/{t['id']}", json={"status": "bogus"}).status_code == 422

def test_event_search_escapes_wildcards(admin):
    key = agent_key(admin, "HOST-S")
    report(admin, key, [{"kind": "custom", "msg": "100% done"}, {"kind": "custom", "msg": "other"}])
    r = admin.get("/api/events", params={"q": "100%"}).json()
    assert len(r) == 1 and r[0]["data"]["msg"] == "100% done"

def test_settings_validation(admin):
    assert admin.put("/api/settings", json={"blocklist": ["not-an-ip"]}).status_code == 422
    assert admin.put("/api/settings", json={"webhook_url": "file:///etc/passwd"}).status_code == 422
    assert admin.put("/api/settings", json={"retention_days": 0}).status_code == 422
    assert admin.put("/api/settings", json={"nope": 1}).status_code == 422

def test_revoked_key_and_password_change_kills_sessions(admin):
    r = admin.post("/api/keys", json={"name": "k", "kind": "agent", "hostname": "HOST-K"}).json()
    assert report(admin, r["key"]).status_code == 200
    admin.delete(f"/api/keys/{r['id']}")
    assert report(admin, r["key"]).status_code == 401
    uid = next(u["id"] for u in admin.get("/api/users").json() if u["username"] == "vera")
    with TestClient(app) as v:
        login(v, "vera", "viewer-password-1")
        admin.patch(f"/api/users/{uid}", json={"password": "another-long-password"})
        assert v.get("/api/overview").status_code == 401

def test_self_service_password_change():
    with TestClient(app) as c:
        admin_pw = "correct-horse-battery"
        login(c)
        assert c.post("/api/auth/password", json={"current": "wrong", "new": "a-very-long-new-password"}).status_code == 403
        assert c.post("/api/auth/password", json={"current": admin_pw, "new": "short"}).status_code == 422
        assert c.post("/api/auth/password", json={"current": admin_pw, "new": "a-very-long-new-password"}).status_code == 200
        assert c.post("/api/auth/password", json={"current": "a-very-long-new-password", "new": admin_pw}).status_code == 200
