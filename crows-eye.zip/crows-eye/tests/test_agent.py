import os, sys, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), "agent"))
from crows_eye_agent import AuthLog, redact

def test_redacts_secrets_in_command_lines():
    assert "hunter2" not in redact("mysql -u root --password hunter2 -h db")
    assert redact("curl x token=hunter2") == "curl x token=***"
    assert redact("app --api-key abc123 --port 80") == "app --api-key *** --port 80"
    assert redact("ls -la /tmp") == "ls -la /tmp"
    assert len(redact("x" * 5000)) == 1000

def test_authlog_parses_and_handles_rotation():
    d = tempfile.mkdtemp(); p = os.path.join(d, "auth.log"); open(p, "w").close()
    a = AuthLog(p); assert a.poll() == []
    with open(p, "a") as f:
        f.write("sshd[1]: Failed password for root from 198.51.100.1 port 22 ssh2\n")
        f.write("sshd[1]: Failed password for invalid user bob from 198.51.100.2 port 22 ssh2\n")
        f.write("sshd[1]: Invalid user eve from 198.51.100.3 port 22\n")
        f.write("sshd[1]: Accepted publickey for alice from 10.0.0.9 port 22 ssh2\n")
        f.write("unrelated line\n")
    ev = a.poll()
    assert [e["kind"] for e in ev] == ["auth_failure"] * 3 + ["auth_success"]
    assert [e["src_ip"] for e in ev] == ["198.51.100.1", "198.51.100.2", "198.51.100.3", "10.0.0.9"]
    os.rename(p, p + ".1")                                   # logrotate
    with open(p, "w") as f: f.write("sshd[1]: Failed password for root from 198.51.100.4 port 22 ssh2\n")
    assert [e["src_ip"] for e in a.poll()] == ["198.51.100.4"]

def test_authlog_missing_file_is_tolerated():
    assert AuthLog("/nonexistent/auth.log").poll() == []
