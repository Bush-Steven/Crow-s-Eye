"use strict";
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const num = (v, d = 0) => Number.isFinite(+v) ? (+v).toFixed(d) : "–";
const fmt = ts => new Date(ts * 1000).toLocaleTimeString([], {hour12: false});
const fmtDT = ts => new Date(ts * 1000).toLocaleString([], {hour12: false});
const ago = ts => { const s = Math.max(0, Date.now() / 1000 - ts); return s < 60 ? `${s | 0}s ago` : s < 3600 ? `${s / 60 | 0}m ago` : s < 86400 ? `${s / 3600 | 0}h ago` : `${s / 86400 | 0}d ago`; };
const STATUSES = ["New", "Investigate", "Open", "Review", "Monitoring", "Resolved"], SEVS = ["CRITICAL", "HIGH", "MEDIUM", "LOW"];
const STATUS_CLASS = {New: "bad", Investigate: "bad", Open: "warn", Review: "warn", Monitoring: "muted", Resolved: "good"};
const PILL = {online: ["online", "ONLINE"], warning: ["watch", "WARNING"], offline: ["offline", "OFFLINE"]};
const LEVEL_COLOR = {CRITICAL: "var(--red)", HIGH: "var(--amber)", MEDIUM: "var(--amber)"};
const state = {user: null, csrf: "", view: null, timers: []};
const isAdmin = () => state.user?.role === "admin", canEdit = () => ["admin", "analyst"].includes(state.user?.role);
const sevBadge = s => `<span class="severity ${esc(String(s).toLowerCase())}">${esc(s)}</span>`;
const opts = (list, sel) => list.map(o => `<option${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");
const meter = v => v == null ? '<span class="muted">–</span>' : `<span class="bar"><i class="${v >= 90 ? "bad" : v >= 75 ? "warn" : ""}" style="width:${Math.min(100, Math.max(0, +v))}%"></i></span> <span class="mono">${num(v)}%</span>`;

// ---------- api / ui helpers ----------
async function api(path, {method = "GET", body} = {}) {
  const r = await fetch("/api" + path, {method, headers: {...(body ? {"Content-Type": "application/json"} : {}), ...(method !== "GET" ? {"X-CSRF-Token": state.csrf} : {})}, body: body ? JSON.stringify(body) : undefined});
  if (r.status === 401 && !path.startsWith("/auth/login")) { showLogin(); throw new Error("Signed out"); }
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(typeof d.detail === "string" ? d.detail : d.detail?.[0]?.msg || `HTTP ${r.status}`);
  return d;
}
const act = fn => async (...a) => { try { await fn(...a); } catch (e) { if (e.message !== "Signed out") toast("Action failed", e.message); } };
function toast(title, message, critical = false) {
  const el = document.createElement("div"); el.className = "toast" + (critical ? " critical-toast" : "");
  el.innerHTML = `<div class="toast-head"><span>${critical ? "⚠ CRITICAL ALERT" : "◉ SECURITY NOTICE"} · ${esc(title)}</span><button aria-label="Dismiss">×</button></div><p>${esc(message)}</p><small>CROW'S EYE / ${new Date().toLocaleTimeString()}</small>`;
  el.querySelector("button").onclick = () => el.remove(); $("#toastStack").prepend(el); setTimeout(() => el.remove(), 8000);
  if ("Notification" in window && Notification.permission === "granted") new Notification("Crow's Eye — " + title, {body: message, tag: "crows-eye-alert"});
}
function dialog(html, wide = false) {
  const box = $("#dlgBox"); box.className = "modal" + (wide ? " wide" : ""); box.innerHTML = html; $("#dlg").classList.add("show");
  $$("[data-close]", box).forEach(b => b.onclick = closeDialog); return box;
}
const closeDialog = () => $("#dlg").classList.remove("show");
$("#dlg").onclick = e => { if (e.target.id === "dlg") closeDialog(); };
const head = t => `<div class="modal-head"><h2>${t}</h2><button data-close aria-label="Close">×</button></div>`;
const every = (fn, ms) => state.timers.push(setInterval(fn, ms));
const debounce = (fn, ms) => { let t; return () => { clearTimeout(t); t = setTimeout(fn, ms); }; };

// ---------- auth ----------
function showLogin() { $("#login").classList.add("show"); $("#lu").focus(); if (state.es) { state.es.close(); state.es = null; } }
$("#loginForm").onsubmit = async e => {
  e.preventDefault(); $("#lerr").textContent = "";
  try { const u = await api("/auth/login", {method: "POST", body: {username: $("#lu").value, password: $("#lp").value}}); $("#lp").value = ""; start(u); }
  catch (err) { $("#lerr").textContent = err.message; }
};
$("#logoutBtn").onclick = act(async () => { await api("/auth/logout", {method: "POST"}); location.reload(); });
function start(u) {
  state.user = u; state.csrf = u.csrf; $("#login").classList.remove("show"); $("#whoami").textContent = `${u.username} · ${u.role}`;
  if (state.es) state.es.close();
  state.es = new EventSource("/api/stream");
  state.es.onmessage = e => {
    const ev = JSON.parse(e.data); refreshAll();
    if (ev.type === "threat" && ev.threat.severity !== "LOW") toast(`${ev.threat.severity} · ${ev.threat.name}`, `${ev.threat.device} · source ${ev.threat.source}`, ev.threat.severity === "CRITICAL");
  };
  route(); refreshChrome();
}

// ---------- chrome (alert badge, status, alert centre) ----------
let noticeDismissed = false;
async function refreshChrome() {
  try {
    const o = await api("/overview"); state.overview = o;
    $("#alertCount").textContent = o.alerts_unread; $("#alertCount").style.display = o.alerts_unread ? "grid" : "none";
    $("#simulateBtn").hidden = !(o.demo && canEdit()); $("#topNotice").style.display = o.demo && !noticeDismissed ? "flex" : "none";
    $("#sensorStatus").innerHTML = `<i class="dot"></i>${o.endpoints.online ? "AGENTS REPORTING" : "AWAITING AGENTS"}`;
    $("#sensorSub").textContent = `${o.endpoints.online}/${o.endpoints.total} endpoints online`;
    const a = await api("/alerts");
    $("#alertList").innerHTML = a.map(x => `<div class="activity-item"><i class="bullet"${LEVEL_COLOR[x.severity] ? ` style="background:${LEVEL_COLOR[x.severity]}"` : ""}></i><div><b>${esc(x.severity)} · ${esc(x.name)}</b><small>${esc(x.device)} · ${fmt(x.ts).slice(0, 5)}</small></div></div>`).join("") || "<p>No alerts in the alert centre.</p>";
  } catch (e) {}
}
const refreshAll = debounce(() => { refreshChrome(); Promise.resolve(state.view?.refresh?.()).catch(() => {}); }, 300);
$("#alertsBtn").onclick = () => $("#alertsModal").classList.add("show");
$("#closeModal").onclick = () => $("#alertsModal").classList.remove("show");
$("#alertsModal").onclick = e => { if (e.target.id === "alertsModal") $("#alertsModal").classList.remove("show"); };
$("#markRead").onclick = act(async () => { await api("/alerts/read", {method: "POST"}); refreshChrome(); });
$("#clearAlerts").onclick = act(async () => { await api("/alerts", {method: "DELETE"}); refreshChrome(); });
$("#dismissNotice").onclick = () => { noticeDismissed = true; $("#topNotice").style.display = "none"; };
$("#simulateBtn").onclick = act(() => api("/dev/simulate", {method: "POST"}));
$("#notifyBtn").onclick = async () => {
  if (!("Notification" in window)) return toast("Unavailable", "This browser does not support desktop notifications.");
  if (await Notification.requestPermission() === "granted") { toast("Browser alerts enabled", "Desktop notifications will appear while this page is open."); $("#notifyBtn").textContent = "Browser alerts enabled"; }
};

// ---------- shared pieces ----------
const deviceRow = x => { const [c, l] = PILL[x.status]; return `<div class="device click" data-host="${esc(x.hostname)}" style="cursor:pointer"><div class="device-icon">▣</div><div class="device-info"><b>${esc(x.hostname)}</b><small>${esc(x.os || "Unknown OS")} · ${esc(x.ip || "no IP")}</small></div><span class="pill ${c}">${l}</span></div>`; };
const activityHtml = a => a.map(x => `<div class="activity-item"><i class="bullet"${LEVEL_COLOR[x.level] ? ` style="background:${LEVEL_COLOR[x.level]}"` : ""}></i><div>${esc(x.text)}<small>${esc(x.device)} · ${esc(x.origin)}</small></div><time>${fmt(x.ts).slice(0, 5)}</time></div>`).join("") || `<p class="muted">No activity yet.</p>`;
const evSummary = e => { const d = e.data; return ({auth_failure: `Failed login ${d.user || ""} from ${d.src_ip || "?"} (${d.service || ""})`, auth_success: `Login ${d.user || ""} from ${d.src_ip || "?"} via ${d.method || ""}`,
  process_start: `${d.process || "?"} — ${d.cmdline || ""}`, connection: `${d.process || "?"} → ${d.dst_ip}:${d.dst_port}`, listening_port: `${d.process || "?"} listening on :${d.port}${d.new ? " (new)" : ""}`}[e.kind]) ?? JSON.stringify(d); };
const spark = (pts, key, color) => { if (pts.length < 2) return ""; const t0 = pts[0].ts, t1 = pts.at(-1).ts || t0 + 1;
  return `<polyline fill="none" stroke="${color}" stroke-width="2" points="${pts.map(p => `${((p.ts - t0) / (t1 - t0 || 1) * 300).toFixed(1)},${(58 - Math.min(100, p[key] || 0) * .56).toFixed(1)}`).join(" ")}"/>`; };

async function showDevice(host) {
  const d = await api("/devices/" + encodeURIComponent(host)), dev = d.device, [pc, pl] = PILL[dev.status];
  const box = dialog(`${head(esc(dev.hostname))}
    <div class="kv mt"><b>STATUS</b><span class="pill ${pc}" style="justify-self:start">${pl}</span><b>OS / IP</b><span>${esc(dev.os || "–")} · ${esc(dev.ip || "–")}</span>
    <b>AGENT</b><span>${esc(dev.version || "–")}</span><b>LAST SEEN</b><span>${ago(dev.last_seen)}</span>
    <b>CPU / MEM / DISK</b><span>${meter(dev.cpu)} ${meter(dev.mem)} ${meter(dev.disk)}</span></div>
    <h3>RESOURCE HISTORY (3H) — <span style="color:#ffc66d">CPU</span> <span style="color:#5ce1d2">MEM</span> <span style="color:#b8f477">DISK</span></h3>
    <svg class="spark" viewBox="0 0 300 60" preserveAspectRatio="none" style="background:#0a1014;border:1px solid var(--line);border-radius:4px">${spark(d.metrics, "cpu", "#ffc66d")}${spark(d.metrics, "mem", "#5ce1d2")}${spark(d.metrics, "disk", "#b8f477")}</svg>
    <h3>DETECTIONS</h3><div class="table-wrap"><table style="min-width:0"><tbody>${d.threats.map(t => `<tr class="click" data-threat="${t.id}"><td>${sevBadge(t.severity)}</td><td>${esc(t.name)}</td><td>${ago(t.ts)}</td><td class="${STATUS_CLASS[t.status] || ""}">${esc(t.status)}</td></tr>`).join("") || '<tr><td class="muted">None</td></tr>'}</tbody></table></div>
    <h3>RECENT EVENTS</h3><div class="table-wrap"><table style="min-width:0"><tbody>${d.events.slice(0, 15).map(e => `<tr><td class="mono">${fmt(e.ts)}</td><td class="mono">${esc(e.kind)}</td><td>${esc(evSummary(e)).slice(0, 160)}</td></tr>`).join("") || '<tr><td class="muted">None</td></tr>'}</tbody></table></div>
    ${isAdmin() ? '<div class="modal-actions"><button class="btn danger" id="delDev">Remove endpoint &amp; revoke its keys</button></div>' : ""}`, true);
  $$("[data-threat]", box).forEach(r => r.onclick = () => showThreat(r.dataset.threat));
  const del = $("#delDev", box); if (del) del.onclick = act(async () => { if (!confirm(`Remove ${dev.hostname} and revoke its API keys?`)) return; await api("/devices/" + encodeURIComponent(dev.hostname), {method: "DELETE"}); closeDialog(); refreshAll(); });
}
async function showThreat(id) {
  const t = await api("/threats/" + id), edit = canEdit();
  const box = dialog(`${head(`${sevBadge(t.severity)} ${esc(t.name)}`)}
    <div class="kv mt"><b>DEVICE</b><span>${esc(t.device)}</span><b>SOURCE</b><span>${esc(t.source)}</span><b>DETECTED</b><span>${fmtDT(t.ts)}</span></div>
    <h3>TRIAGE</h3><div class="form"><div class="two"><label>STATUS<select class="in" id="tStatus" ${edit ? "" : "disabled"}>${opts(STATUSES, t.status)}</select></label>
    <label>ASSIGNEE<input class="in" id="tAssignee" maxlength="64" value="${esc(t.assignee)}" ${edit ? "" : "disabled"}></label></div>
    <label>NOTES<textarea class="in" id="tNotes" rows="3" maxlength="4000" ${edit ? "" : "disabled"}>${esc(t.notes)}</textarea></label></div>
    <h3>EVIDENCE</h3><pre>${esc(typeof t.detail === "string" ? t.detail : JSON.stringify(t.detail, null, 2))}</pre>
    <div class="modal-actions">${edit ? '<button class="btn primary" id="tSave">Save</button>' : ""}<button class="btn" data-close>Close</button></div>`, true);
  const s = $("#tSave", box); if (s) s.onclick = act(async () => { await api("/threats/" + id, {method: "PATCH", body: {status: $("#tStatus").value, assignee: $("#tAssignee").value, notes: $("#tNotes").value}}); closeDialog(); refreshAll(); });
}
const bindHosts = root => $$("[data-host]", root).forEach(r => r.onclick = act(() => showDevice(r.dataset.host)));

// ---------- views ----------
const VIEWS = {};
VIEWS.overview = {title: "System Overview", eyebrow: "SECURITY OPERATIONS CENTER / LOCAL NETWORK",
  render: v => { v.innerHTML = `<section class="grid">
    <article class="metric"><div class="label">ENDPOINTS MONITORED</div><div class="value" id="mEndpoints">--</div><div class="sub" id="mEndpointsSub">&nbsp;</div></article>
    <article class="metric"><div class="label">THREATS DETECTED</div><div class="value bad" id="mThreats">--</div><div class="sub" id="mThreatsSub">&nbsp;</div></article>
    <article class="metric"><div class="label">NETWORK TRAFFIC</div><div class="value cyan" id="mTraffic">0.0 <small style="font-size:15px">Mbps</small></div><div class="sub">Inbound + outbound, all endpoints</div></article>
    <article class="metric"><div class="label">SYSTEM HEALTH</div><div class="value good" id="mHealth"><span id="mHealthNum">--</span><span style="font-size:19px">%</span></div><div class="sub">Fleet health score</div></article></section>
    <div class="section-head"><h2>Live monitoring</h2><small id="lastUpdated"></small></div>
    <section class="two-col"><article class="panel"><div class="panel-title"><h3>Network traffic</h3><small>SOLID INBOUND · DASHED OUTBOUND · Mbps</small></div>
    <div class="chart"><svg viewBox="0 0 600 180" preserveAspectRatio="none"><defs><linearGradient id="fillA" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#5ce1d2" stop-opacity=".27"/><stop offset="1" stop-color="#5ce1d2" stop-opacity="0"/></linearGradient></defs>
    <path id="trafficArea" d="" fill="url(#fillA)"/><polyline id="trafficIn" points="" fill="none" stroke="#5ce1d2" stroke-width="2.5"/><polyline id="trafficOut" points="" fill="none" stroke="#b8f477" stroke-width="1.5" stroke-dasharray="4 4"/></svg></div>
    <div class="chart-labels"><span>-60s</span><span>-45s</span><span>-30s</span><span>-15s</span><span>NOW</span></div></article>
    <article class="panel"><div class="panel-title"><h3>Endpoint status</h3><small id="deviceCount"></small></div><div id="deviceList"></div></article></section>
    <div class="section-head"><h2>Threat detections</h2><small>MOST RECENT · <a href="#/threats" style="color:var(--green)">VIEW ALL</a></small></div>
    <section class="panel table-wrap"><table><thead><tr><th>SEVERITY</th><th>DETECTION</th><th>SOURCE</th><th>DEVICE</th><th>TIME</th><th>STATUS</th></tr></thead><tbody id="threatRows"></tbody></table></section>
    <div class="section-head"><h2>Activity timeline</h2><small>RECENT EVENTS</small></div><section class="panel activity" id="activity"></section>`;
    every(loadTraffic, 3000); },
  async refresh() {
    const [o, d, t, a] = await Promise.all([api("/overview"), api("/devices"), api("/threats?limit=6"), api("/activity?limit=12")]);
    $("#mEndpoints").textContent = String(o.endpoints.total).padStart(2, "0");
    $("#mEndpointsSub").innerHTML = `<span class="good">● ${o.endpoints.online} online</span> · ${o.endpoints.offline} offline`;
    $("#mThreats").textContent = o.threats.total; $("#mThreatsSub").textContent = `${o.threats.needs_investigation} require investigation`;
    $("#mTraffic").firstChild.textContent = num(o.traffic.total_mbps, 1) + " "; $("#mHealthNum").textContent = o.health;
    $("#mHealth").className = "value " + (o.health >= 85 ? "good" : o.health >= 60 ? "warn" : "bad");
    $("#deviceCount").textContent = `${d.length} DEVICES`; $("#deviceList").innerHTML = d.slice(0, 8).map(deviceRow).join("") || `<p class="muted">No endpoints yet. Add one under Computers.</p>`; bindHosts($("#deviceList"));
    $("#threatRows").innerHTML = t.map(x => `<tr class="click" data-threat="${x.id}"><td>${sevBadge(x.severity)}</td><td>${esc(x.name)}</td><td>${esc(x.source)}</td><td>${esc(x.device)}</td><td>${fmt(x.ts)}</td><td class="${STATUS_CLASS[x.status] || ""}">${esc(x.status)}</td></tr>`).join("") || `<tr><td colspan="6" class="muted">No detections recorded.</td></tr>`;
    $$("#threatRows [data-threat]").forEach(r => r.onclick = act(() => showThreat(r.dataset.threat)));
    $("#activity").innerHTML = activityHtml(a); $("#lastUpdated").textContent = "LAST UPDATE: " + new Date().toLocaleTimeString().toUpperCase(); loadTraffic();
  }};
async function loadTraffic() {
  if (!$("#trafficIn")) return;
  const {now, seconds, points} = await api("/traffic?seconds=60"), max = Math.max(10, ...points.map(p => Math.max(p.inbound, p.outbound)));
  const xy = k => points.map(p => [(p.t - (now - seconds)) / seconds * 600, 170 - p[k] / max * 150]), line = a => a.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" "), inb = xy("inbound");
  $("#trafficIn").setAttribute("points", line(inb)); $("#trafficOut").setAttribute("points", line(xy("outbound")));
  $("#trafficArea").setAttribute("d", inb.length > 1 ? `M${inb[0][0].toFixed(1)} 180 ` + inb.map(([x, y]) => `L${x.toFixed(1)} ${y.toFixed(1)}`).join(" ") + ` L${inb.at(-1)[0].toFixed(1)} 180Z` : "");
}

VIEWS.computers = {title: "Computers", eyebrow: "ENDPOINT INVENTORY",
  render: v => { v.innerHTML = `<div class="row sb"><span class="muted">Click an endpoint for details.</span>${isAdmin() ? '<button class="btn primary" id="addEp">＋ Add endpoint</button>' : ""}</div>
    <section class="panel table-wrap mt"><table><thead><tr><th>ENDPOINT</th><th>STATUS</th><th>OS</th><th>IP</th><th>CPU</th><th>MEMORY</th><th>DISK</th><th>AGENT</th><th>LAST SEEN</th></tr></thead><tbody id="rows"></tbody></table></section>`;
    const a = $("#addEp"); if (a) a.onclick = addEndpoint; },
  async refresh() {
    const d = await api("/devices");
    $("#rows").innerHTML = d.map(x => { const [c, l] = PILL[x.status]; return `<tr class="click" data-host="${esc(x.hostname)}"><td><b>${esc(x.hostname)}</b></td><td><span class="pill ${c}">${l}</span></td><td>${esc(x.os)}</td><td class="mono">${esc(x.ip)}</td><td>${meter(x.cpu)}</td><td>${meter(x.mem)}</td><td>${meter(x.disk)}</td><td class="mono">${esc(x.version)}</td><td class="muted">${ago(x.last_seen)}</td></tr>`; }).join("") || `<tr><td colspan="9" class="muted">No endpoints yet.</td></tr>`;
    bindHosts($("#rows"));
  }};
function addEndpoint() {
  const box = dialog(`${head("Add endpoint")}<p>Creates an API key bound to one hostname. The key is shown once.</p>
    <form class="form" id="f"><label>HOSTNAME<input class="in" id="host" pattern="[A-Za-z0-9_.\\-]{1,100}" required placeholder="WORKSTATION-05"></label><button class="btn primary">Create key</button></form>`);
  $("#f", box).onsubmit = act(async e => { e.preventDefault(); const h = $("#host").value, r = await api("/keys", {method: "POST", body: {name: h, kind: "agent", hostname: h}}); showKey(r.key, `agent for ${h}`, true); });
}
function showKey(key, label, agent) {
  const cmd = `CROWS_EYE_URL=${location.origin} CROWS_EYE_API_KEY=${key} python3 crows_eye_agent.py`;
  dialog(`${head("API key created")}<p>Copy this key now — it cannot be shown again. (${esc(label)})</p><pre id="kv">${esc(key)}</pre>
    ${agent ? `<h3>INSTALL ON THE ENDPOINT</h3><pre>pip install psutil\n${esc(cmd)}</pre>` : ""}<div class="modal-actions"><button class="btn primary" id="cp">Copy key</button><button class="btn" data-close>Done</button></div>`);
  $("#cp").onclick = () => navigator.clipboard?.writeText(key).then(() => toast("Copied", "API key copied to clipboard"), () => toast("Copy failed", "Select the key text manually"));
}

VIEWS.network = {title: "Network Map", eyebrow: "LAST 15 MINUTES OF OBSERVED CONNECTIONS",
  render: v => { v.innerHTML = `<div class="row"><span class="pill online">ONLINE</span><span class="pill watch">WARNING</span><span class="pill offline">OFFLINE</span><span class="muted">Red links go to blocklisted addresses. Click an endpoint for details.</span></div><div class="mt"><svg id="net" class="net" viewBox="0 0 900 560"></svg></div>`; },
  async refresh() {
    const {devices, edges} = await api("/network"), cx = 450, cy = 280, byIp = Object.fromEntries(devices.filter(d => d.ip).map(d => [d.ip, d.hostname]));
    const pos = {}; devices.forEach((d, i) => { const a = i / Math.max(1, devices.length) * 2 * Math.PI - Math.PI / 2; pos[d.hostname] = [cx + 150 * Math.cos(a), cy + 150 * Math.sin(a)]; });
    const ext = {}; edges.forEach(e => { if (!byIp[e.ip]) { const x = ext[e.ip] ||= {ip: e.ip, n: 0, bl: false}; x.n += e.n; x.bl ||= e.blocklisted; } });
    const ex = Object.values(ext).sort((a, b) => b.n - a.n).slice(0, 14); ex.forEach((x, i) => { const a = i / Math.max(1, ex.length) * 2 * Math.PI - Math.PI / 2 + .2; x.p = [cx + 245 * Math.cos(a) * 1.5, cy + 245 * Math.sin(a) * 1.05]; });
    let g = `<circle cx="${cx}" cy="${cy}" r="26" style="fill:#13201f;stroke:var(--green)"/><text x="${cx}" y="${cy + 4}" text-anchor="middle">LAN</text>`;
    devices.forEach(d => g = `<line x1="${cx}" y1="${cy}" x2="${pos[d.hostname][0]}" y2="${pos[d.hostname][1]}" style="stroke:#26343b"/>` + g);
    edges.forEach(e => { const a = pos[e.device], t = byIp[e.ip] ? pos[byIp[e.ip]] : ext[e.ip]?.p; if (a && t && a !== t) g = `<line x1="${a[0]}" y1="${a[1]}" x2="${t[0]}" y2="${t[1]}" style="stroke:${e.blocklisted ? "var(--red)" : "#2f6b66"};stroke-width:${Math.min(4, 1 + Math.log2(e.n))}"/>` + g; });
    ex.forEach(x => g += `<rect x="${x.p[0] - 5}" y="${x.p[1] - 5}" width="10" height="10" style="fill:${x.bl ? "var(--red)" : "var(--blue)"}"/><text x="${x.p[0]}" y="${x.p[1] - 9}" text-anchor="middle">${esc(x.ip)}</text>`);
    devices.forEach(d => { const [x, y] = pos[d.hostname], col = {online: "var(--green)", warning: "var(--amber)", offline: "var(--red)"}[d.status];
      g += `<g data-host="${esc(d.hostname)}" style="cursor:pointer"><circle cx="${x}" cy="${y}" r="13" style="fill:#10171d;stroke:${col};stroke-width:2"/><text x="${x}" y="${y + 26}" text-anchor="middle">${esc(d.hostname)}</text></g>`; });
    $("#net").innerHTML = g; bindHosts($("#net"));
  }};

VIEWS.threats = {title: "Threat Detection", eyebrow: "DETECTIONS & TRIAGE",
  render: v => { v.innerHTML = `<div class="row"><select class="in" id="fSev"><option value="">All severities</option>${opts(SEVS)}</select><select class="in" id="fStatus"><option value="">All statuses</option>${opts(STATUSES)}</select>
    <input class="in" id="fQ" placeholder="Search name, source, device…" style="flex:1;min-width:180px"></div>
    <section class="panel table-wrap mt"><table><thead><tr><th>SEVERITY</th><th>DETECTION</th><th>SOURCE</th><th>DEVICE</th><th>TIME</th><th>ASSIGNEE</th><th>STATUS</th></tr></thead><tbody id="rows"></tbody></table></section>`;
    const r = debounce(() => VIEWS.threats.refresh(), 250); $$("#fSev,#fStatus").forEach(e => e.onchange = r); $("#fQ").oninput = r; },
  async refresh() {
    const p = new URLSearchParams({limit: 200}); [["severity", "#fSev"], ["status", "#fStatus"], ["q", "#fQ"]].forEach(([k, s]) => $(s).value && p.set(k, $(s).value));
    const t = await api("/threats?" + p);
    $("#rows").innerHTML = t.map(x => `<tr class="click" data-threat="${x.id}"><td>${sevBadge(x.severity)}</td><td>${esc(x.name)}</td><td>${esc(x.source)}</td><td>${esc(x.device)}</td><td>${fmtDT(x.ts)}</td><td>${esc(x.assignee) || '<span class="muted">–</span>'}</td><td class="${STATUS_CLASS[x.status] || ""}">${esc(x.status)}</td></tr>`).join("") || `<tr><td colspan="7" class="muted">No matching detections.</td></tr>`;
    $$("#rows [data-threat]").forEach(r => r.onclick = act(() => showThreat(r.dataset.threat)));
  }};

VIEWS.timeline = {title: "Event Timeline", eyebrow: "RAW TELEMETRY FROM ENDPOINT AGENTS",
  render: v => { state.beforeId = null; v.innerHTML = `<div class="row"><select class="in" id="fKind"><option value="">All event types</option>${opts(["auth_failure", "auth_success", "process_start", "connection", "listening_port", "custom"])}</select>
    <input class="in" id="fDev" placeholder="Device" style="width:160px"><input class="in" id="fQ" placeholder="Search event contents…" style="flex:1;min-width:180px"></div>
    <section class="panel table-wrap mt"><table><thead><tr><th>TIME</th><th>DEVICE</th><th>TYPE</th><th>DETAILS</th></tr></thead><tbody id="rows"></tbody></table></section>
    <div class="row mt"><button class="btn" id="more" hidden>Load older</button></div>`;
    const r = debounce(() => VIEWS.timeline.refresh(), 300); $$("#fKind,#fDev,#fQ").forEach(e => { e.onchange = r; e.oninput = r; }); $("#more").onclick = act(() => VIEWS.timeline.load(true)); },
  refresh() { return this.load(false); },
  async load(append) {
    const p = new URLSearchParams({limit: 100}); [["kind", "#fKind"], ["device", "#fDev"], ["q", "#fQ"]].forEach(([k, s]) => $(s).value && p.set(k, $(s).value));
    if (append && state.beforeId) p.set("before_id", state.beforeId);
    const ev = await api("/events?" + p), html = ev.map(e => `<tr><td class="mono">${fmtDT(e.ts)}</td><td>${esc(e.device)}</td><td class="mono">${esc(e.kind)}</td><td>${esc(evSummary(e)).slice(0, 220)}</td></tr>`).join("");
    if (append) $("#rows").insertAdjacentHTML("beforeend", html); else $("#rows").innerHTML = html || `<tr><td colspan="4" class="muted">No events match.</td></tr>`;
    if (ev.length) state.beforeId = ev.at(-1).id; $("#more").hidden = ev.length < 100;
  }};

VIEWS.rules = {title: "Alert Rules", eyebrow: "DETECTION LOGIC",
  render: v => { v.innerHTML = `<div class="row sb"><span class="muted">Agents send raw events; these rules decide what becomes a detection.${isAdmin() ? "" : " (Read-only: admin role required to edit.)"}</span>${isAdmin() ? '<button class="btn primary" id="newRule">＋ New rule</button>' : ""}</div>
    <section class="panel table-wrap mt"><table><thead><tr><th>ON</th><th>RULE</th><th>EVENT TYPE</th><th>SEVERITY</th><th>CONDITIONS</th><th>THRESHOLD</th><th>COOLDOWN</th>${isAdmin() ? "<th></th>" : ""}</tr></thead><tbody id="rows"></tbody></table></section>`;
    const n = $("#newRule"); if (n) n.onclick = () => ruleForm(); },
  async refresh() {
    const {rules, kinds, ops} = await api("/rules"); state.ruleMeta = {kinds, ops}; state.rules = rules;
    const cond = r => r.match.map(c => `${esc(c.field)} ${esc(c.op)} ${esc(JSON.stringify(c.value))}`).join("<br>") || '<span class="muted">any</span>';
    $("#rows").innerHTML = rules.map(r => `<tr><td><span class="pill ${r.enabled ? "online" : "dis"}">${r.enabled ? "ON" : "OFF"}</span></td><td><b>${esc(r.name)}</b></td><td class="mono">${esc(r.kind)}</td><td>${sevBadge(r.severity)}</td><td class="mono">${cond(r)}</td>
      <td class="mono">${r.threshold ? `${r.threshold.count} in ${r.threshold.window}s${r.threshold.group_by ? " by " + esc(r.threshold.group_by) : ""}` : "each event"}</td><td class="mono">${r.cooldown}s</td>
      ${isAdmin() ? `<td><button class="btn sm" data-edit="${r.id}">Edit</button></td>` : ""}</tr>`).join("");
    $$("[data-edit]").forEach(b => b.onclick = () => ruleForm(state.rules.find(r => r.id == b.dataset.edit)));
  }};
function ruleForm(r) {
  const R = r || {name: "", enabled: true, severity: "MEDIUM", kind: "custom", match: [], threshold: null, cooldown: 300}, {kinds, ops} = state.ruleMeta;
  const condRow = c => `<div class="row cond"><input class="in cf" placeholder="field (e.g. cmdline)" value="${esc(c.field)}" style="width:130px"><select class="in co">${opts(ops, c.op)}</select><input class="in cv" placeholder="value" value="${esc(Array.isArray(c.value) ? c.value.join(",") : c.value ?? "")}" style="flex:1"><button type="button" class="btn sm danger cx">×</button></div>`;
  const box = dialog(`${head(r ? "Edit rule" : "New rule")}<form class="form" id="f">
    <label>NAME<input class="in" id="rName" maxlength="120" required value="${esc(R.name)}"></label>
    <div class="two"><label>EVENT TYPE<select class="in" id="rKind">${opts(kinds, R.kind)}</select></label><label>SEVERITY<select class="in" id="rSev">${opts(SEVS, R.severity)}</select></label></div>
    <label>CONDITIONS (all must match). Ops: ${esc(ops.join(", "))}. For is_private / in_blocklist use true or false; for "in" use a comma list.</label>
    <div id="conds" class="form">${R.match.map(condRow).join("")}</div><div><button type="button" class="btn sm" id="addC">＋ Condition</button></div>
    <label class="row" style="flex-direction:row"><input type="checkbox" id="rTh" ${R.threshold ? "checked" : ""}> THRESHOLD: fire only after repeated events</label>
    <div class="form" id="thBox" style="${R.threshold ? "" : "display:none"}"><div class="two"><label>COUNT<input class="in" id="thC" type="number" min="1" value="${R.threshold?.count ?? 5}"></label><label>WINDOW (SECONDS)<input class="in" id="thW" type="number" min="1" value="${R.threshold?.window ?? 60}"></label></div>
    <label>GROUP BY FIELD (optional, e.g. src_ip)<input class="in" id="thG" value="${esc(R.threshold?.group_by || "")}"></label></div>
    <div class="two"><label>COOLDOWN (SECONDS)<input class="in" id="rCool" type="number" min="0" max="86400" value="${R.cooldown}"></label><label class="row" style="flex-direction:row;align-self:end"><input type="checkbox" id="rOn" ${R.enabled ? "checked" : ""}> ENABLED</label></div>
    <div class="modal-actions"><button class="btn primary">Save</button><button type="button" class="btn" data-close>Cancel</button>${r ? '<button type="button" class="btn danger" id="rDel">Delete</button>' : ""}</div></form>`, true);
  const bindX = () => $$(".cx", box).forEach(b => b.onclick = () => b.closest(".cond").remove());
  bindX(); $("#addC", box).onclick = () => { $("#conds", box).insertAdjacentHTML("beforeend", condRow({field: "", op: "eq", value: ""})); bindX(); };
  $("#rTh", box).onchange = e => $("#thBox", box).style.display = e.target.checked ? "" : "none";
  const parse = (op, v) => ["is_private", "in_blocklist"].includes(op) ? v.trim().toLowerCase() !== "false" : op === "in" ? v.split(",").map(x => x.trim()).filter(Boolean) : v;
  $("#f", box).onsubmit = act(async e => { e.preventDefault();
    const body = {name: $("#rName").value, enabled: $("#rOn").checked, severity: $("#rSev").value, kind: $("#rKind").value, cooldown: +$("#rCool").value,
      match: $$(".cond", box).map(c => ({field: $(".cf", c).value.trim(), op: $(".co", c).value, value: parse($(".co", c).value, $(".cv", c).value)})),
      threshold: $("#rTh").checked ? {count: +$("#thC").value, window: +$("#thW").value, group_by: $("#thG").value.trim() || null} : null};
    await api(r ? "/rules/" + r.id : "/rules", {method: r ? "PUT" : "POST", body}); closeDialog(); VIEWS.rules.refresh(); });
  const d = $("#rDel", box); if (d) d.onclick = act(async () => { if (confirm("Delete this rule?")) { await api("/rules/" + r.id, {method: "DELETE"}); closeDialog(); VIEWS.rules.refresh(); } });
}

VIEWS.settings = {title: "Settings", eyebrow: "ADMINISTRATION",
  render: v => { v.innerHTML = `<section class="panel"><div class="panel-title"><h3>Your account</h3></div><form class="form" id="pwF" style="max-width:420px"><label>CURRENT PASSWORD<input class="in" type="password" id="pwC" autocomplete="current-password" required></label>
    <label>NEW PASSWORD (10+ characters)<input class="in" type="password" id="pwN" autocomplete="new-password" minlength="10" required></label><button class="btn primary" style="justify-self:start">Change password</button></form></section>
    ${isAdmin() ? `<div id="adm"></div>` : `<p class="muted mt">Other settings require the admin role.</p>`}`;
    $("#pwF").onsubmit = act(async e => { e.preventDefault(); await api("/auth/password", {method: "POST", body: {current: $("#pwC").value, new: $("#pwN").value}}); e.target.reset(); toast("Password changed", "Other sessions were signed out."); }); },
  async refresh() {
    if (!isAdmin() || $("#adm")?.dataset.ready) return; $("#adm").dataset.ready = 1;
    const s = await api("/settings"); const f = (id, label, val, type = "text", extra = "") => `<label>${label}<input class="in" id="${id}" type="${type}" value="${esc(val)}" ${extra}></label>`;
    $("#adm").innerHTML = `<section class="panel mt"><div class="panel-title"><h3>Detection &amp; retention</h3></div><form class="form" id="s1" style="max-width:620px">
      <div class="two">${f("offline_after", "OFFLINE AFTER (SECONDS, 30–3600)", s.offline_after, "number")}${f("retention_days", "KEEP RAW EVENTS (DAYS, 1–365)", s.retention_days, "number")}</div>
      <label>BLOCKLIST — one IP or CIDR per line (used by "in_blocklist" rules)<textarea class="in" id="blocklist" rows="5">${esc(s.blocklist.join("\n"))}</textarea></label><button class="btn primary" style="justify-self:start">Save</button></form></section>
    <section class="panel mt"><div class="panel-title"><h3>Notifications</h3></div><form class="form" id="s2" style="max-width:620px">
      ${f("webhook_url", "WEBHOOK URL (Slack-compatible JSON; leave blank to disable)", s.webhook_url, "url")}<label>WEBHOOK MIN SEVERITY<select class="in" id="webhook_min_severity">${opts([...SEVS].reverse(), s.webhook_min_severity)}</select></label>
      <label class="row" style="flex-direction:row"><input type="checkbox" id="email_enabled" ${s.email_enabled ? "checked" : ""}> EMAIL ALERTS (SMTP password is read from the CROWS_EYE_SMTP_PASSWORD environment variable)</label>
      <div class="two">${f("smtp_host", "SMTP HOST", s.smtp_host)}${f("smtp_port", "SMTP PORT (STARTTLS)", s.smtp_port, "number")}</div><div class="two">${f("smtp_user", "SMTP USER", s.smtp_user)}${f("smtp_from", "FROM ADDRESS", s.smtp_from)}</div>
      ${f("email_to", "SEND TO", s.email_to)}<label>EMAIL MIN SEVERITY<select class="in" id="email_min_severity">${opts([...SEVS].reverse(), s.email_min_severity)}</select></label>
      <div class="row"><button class="btn primary">Save</button><button type="button" class="btn" id="testN">Send test notification</button></div></form></section>
    <section class="panel mt"><div class="panel-title"><h3>API keys</h3><button class="btn sm" id="newInt">＋ Integration key (Wazuh etc.)</button></div><div class="table-wrap"><table><thead><tr><th>NAME</th><th>TYPE</th><th>HOST</th><th>LAST USED</th><th></th></tr></thead><tbody id="keyRows"></tbody></table></div></section>
    <section class="panel mt"><div class="panel-title"><h3>Users</h3><button class="btn sm" id="newUser">＋ New user</button></div><div class="table-wrap"><table><thead><tr><th>USER</th><th>ROLE</th><th>STATE</th><th></th></tr></thead><tbody id="userRows"></tbody></table></div></section>
    <section class="panel mt"><div class="panel-title"><h3>Audit log</h3><small>LAST 100 ADMIN / AUTH ACTIONS</small></div><div class="table-wrap"><table><thead><tr><th>TIME</th><th>USER</th><th>ACTION</th><th>DETAIL</th></tr></thead><tbody id="auditRows"></tbody></table></div></section>`;
    const save = (formId, ids, conv = {}) => $(formId).onsubmit = act(async e => { e.preventDefault(); const body = {};
      ids.forEach(i => { const el = $("#" + i); body[i] = conv[i] ? conv[i](el.value) : el.type === "checkbox" ? el.checked : el.type === "number" ? +el.value : el.value; });
      await api("/settings", {method: "PUT", body}); toast("Settings saved", "Changes are active immediately."); });
    save("#s1", ["offline_after", "retention_days", "blocklist"], {blocklist: v => v.split("\n").map(x => x.trim()).filter(Boolean)});
    save("#s2", ["webhook_url", "webhook_min_severity", "email_enabled", "smtp_host", "smtp_port", "smtp_user", "smtp_from", "email_to", "email_min_severity"]);
    $("#testN").onclick = act(async () => { const r = await api("/settings/test-notification", {method: "POST"}); toast("Test notification", Object.entries(r).map(([k, v]) => `${k}: ${v}`).join(" · ")); });
    $("#newInt").onclick = () => { const b = dialog(`${head("New integration key")}<form class="form" id="f"><label>NAME<input class="in" id="kn" required maxlength="80" placeholder="wazuh-manager"></label><button class="btn primary">Create</button></form>`);
      $("#f", b).onsubmit = act(async e => { e.preventDefault(); const r = await api("/keys", {method: "POST", body: {name: $("#kn").value, kind: "integration"}}); showKey(r.key, "integration", false); loadAdmin(); }); };
    $("#newUser").onclick = () => { const b = dialog(`${head("New user")}<form class="form" id="f"><label>USERNAME<input class="in" id="un" required pattern="[A-Za-z0-9_.\\-]{2,40}"></label><label>PASSWORD (10+)<input class="in" id="up" type="password" minlength="10" required autocomplete="new-password"></label>
      <label>ROLE<select class="in" id="ur"><option>viewer</option><option>analyst</option><option>admin</option></select></label><button class="btn primary">Create</button></form>`);
      $("#f", b).onsubmit = act(async e => { e.preventDefault(); await api("/users", {method: "POST", body: {username: $("#un").value, password: $("#up").value, role: $("#ur").value}}); closeDialog(); loadAdmin(); }); };
    loadAdmin();
  }};
const loadAdmin = act(async () => {
  const [keys, users, audit] = await Promise.all([api("/keys"), api("/users"), api("/audit")]);
  $("#keyRows").innerHTML = keys.map(k => `<tr><td>${esc(k.name)}</td><td class="mono">${esc(k.kind)}</td><td class="mono">${esc(k.hostname || "–")}</td><td class="muted">${k.last_used ? ago(k.last_used) : "never"}</td><td>${k.revoked ? '<span class="pill offline">REVOKED</span>' : `<button class="btn sm danger" data-rk="${k.id}">Revoke</button>`}</td></tr>`).join("") || `<tr><td colspan="5" class="muted">No keys yet.</td></tr>`;
  $$("[data-rk]").forEach(b => b.onclick = act(async () => { if (confirm("Revoke this key? Agents using it will stop reporting.")) { await api("/keys/" + b.dataset.rk, {method: "DELETE"}); loadAdmin(); } }));
  $("#userRows").innerHTML = users.map(u => `<tr><td>${esc(u.username)}</td><td><select class="in" data-role="${u.id}">${opts(["viewer", "analyst", "admin"], u.role)}</select></td><td>${u.disabled ? '<span class="pill offline">DISABLED</span>' : '<span class="pill online">ACTIVE</span>'}</td>
    <td class="row"><button class="btn sm" data-pw="${u.id}">Reset password</button><button class="btn sm" data-dis="${u.id}" data-state="${u.disabled}">${u.disabled ? "Enable" : "Disable"}</button><button class="btn sm danger" data-del="${u.id}">Delete</button></td></tr>`).join("");
  $$("[data-role]").forEach(s => s.onchange = act(async () => { await api("/users/" + s.dataset.role, {method: "PATCH", body: {role: s.value}}); loadAdmin(); }));
  $$("[data-dis]").forEach(b => b.onclick = act(async () => { await api("/users/" + b.dataset.dis, {method: "PATCH", body: {disabled: b.dataset.state !== "1"}}); loadAdmin(); }));
  $$("[data-del]").forEach(b => b.onclick = act(async () => { if (confirm("Delete this user?")) { await api("/users/" + b.dataset.del, {method: "DELETE"}); loadAdmin(); } }));
  $$("[data-pw]").forEach(b => b.onclick = act(async () => { const p = prompt("New password (10+ characters):"); if (p) { await api("/users/" + b.dataset.pw, {method: "PATCH", body: {password: p}}); toast("Password reset", "That user was signed out."); } }));
  $("#auditRows").innerHTML = audit.map(a => `<tr><td class="mono">${fmtDT(a.ts)}</td><td>${esc(a.user)}</td><td class="mono">${esc(a.action)}</td><td>${esc(a.detail)}</td></tr>`).join("");
});

// ---------- router ----------
function route() {
  const name = (location.hash.replace(/^#\/?/, "") || "overview"), v = VIEWS[name] || VIEWS.overview, key = VIEWS[name] ? name : "overview";
  state.timers.forEach(clearInterval); state.timers = []; closeDialog(); state.view = v;
  $$(".nav button").forEach(b => b.classList.toggle("active", b.dataset.route === key));
  $("#pageTitle").textContent = v.title; $("#pageEyebrow").textContent = v.eyebrow;
  v.render($("#view")); act(() => v.refresh())(); every(() => v.refresh().catch?.(() => {}), 30000);
}
$$(".nav button").forEach(b => b.onclick = () => { location.hash = "#/" + b.dataset.route; });
window.addEventListener("hashchange", () => state.user && route());
(async () => { try { start(await api("/auth/me")); } catch { showLogin(); } })();
