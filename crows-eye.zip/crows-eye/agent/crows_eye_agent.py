#!/usr/bin/env python3
"""Crow's Eye endpoint agent. Monitors ONLY the host it runs on and reports to your Crow's Eye server.

Collects: CPU/memory/disk, network throughput, new processes (command lines, secrets redacted), new outbound
connections, new listening ports, and SSH/PAM authentication events from the Linux auth log.
Run as root (or a user able to read the auth log / all process info) for full visibility.

  CROWS_EYE_URL=https://ce.example.org CROWS_EYE_API_KEY=ce_... python3 crows_eye_agent.py
"""
import argparse, collections, ipaddress, json, os, platform, re, signal, socket, sys, time, urllib.error, urllib.request
import psutil

VERSION = "1.0.0"
log = lambda *a: print(time.strftime("%H:%M:%S"), "[crows-eye-agent]", *a, file=sys.stderr, flush=True)
REDACT = [re.compile(r"(?i)(--?(?:password|passwd|pwd|token|secret|api[-_]?key)[= ]+)\S+"),
          re.compile(r"(?i)\b((?:password|passwd|pwd|token|secret|apikey)=)\S+")]

def redact(s: str) -> str:
    for r in REDACT: s = r.sub(r"\1***", s)
    return s[:1000]

class AuthLog:
    FAIL = [re.compile(r"Failed \S+ for (?:invalid user )?(\S+) from (\S+)"), re.compile(r"Invalid user (\S+) from (\S+)"),
            re.compile(r"authentication failure;.*rhost=(\S+).*?user=(\S+)")]
    OK = re.compile(r"Accepted (\S+) for (\S+) from (\S+)")
    def __init__(self, path):
        self.path = path; self.f = None; self.ino = None
    def _open(self, seek_end):
        self.f = open(self.path, "r", errors="replace"); self.ino = os.fstat(self.f.fileno()).st_ino
        if seek_end: self.f.seek(0, os.SEEK_END)
    def poll(self):
        ev = []
        try:
            if self.f is None: self._open(True)
            st = os.stat(self.path)
            if st.st_ino != self.ino or st.st_size < self.f.tell(): self._open(False)      # rotated/truncated
            for _ in range(2000):
                line = self.f.readline()
                if not line: break
                m = self.FAIL[0].search(line) or self.FAIL[1].search(line)
                if m: ev.append({"kind": "auth_failure", "user": m.group(1)[:64], "src_ip": m.group(2), "service": "sshd"}); continue
                m = self.FAIL[2].search(line)
                if m: ev.append({"kind": "auth_failure", "src_ip": m.group(1), "user": m.group(2)[:64], "service": "pam"}); continue
                m = self.OK.search(line)
                if m: ev.append({"kind": "auth_success", "method": m.group(1), "user": m.group(2)[:64], "src_ip": m.group(3), "service": "sshd"})
        except (FileNotFoundError, PermissionError) as e:
            if self.f is not None or not getattr(self, "warned", False): log(f"auth log unavailable ({e}); skipping"); self.warned = True
            self.f = None
        return ev

class Processes:
    def __init__(self): self.known = {(p.pid, p.create_time()) for p in self._iter()}
    @staticmethod
    def _iter():
        for p in psutil.process_iter():
            try: p.create_time(); yield p
            except (psutil.NoSuchProcess, psutil.AccessDenied): pass
    def poll(self):
        ev, now = [], set()
        for p in self._iter():
            try:
                key = (p.pid, p.create_time()); now.add(key)
                if key in self.known: continue
                ev.append({"kind": "process_start", "pid": p.pid, "ppid": p.ppid(), "process": p.name()[:100],
                           "cmdline": redact(" ".join(p.cmdline())), "user": (p.username() or "")[:64]})
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess): pass
        self.known = now
        return ev[:300]

def _pname(pid):
    try: return psutil.Process(pid).name()[:100] if pid else ""
    except psutil.Error: return ""

class Connections:
    def __init__(self): self.seen = set(); self.ports = {c.laddr.port for c in self._all() if c.status == "LISTEN"}; self.denied = False
    @staticmethod
    def _all():
        try: return psutil.net_connections(kind="inet")
        except (psutil.AccessDenied, PermissionError): return []
    def poll(self):
        ev = []
        if len(self.seen) > 50000: self.seen.clear()
        for c in self._all():
            if c.status == "ESTABLISHED" and c.raddr and not ipaddress.ip_address(c.raddr.ip).is_loopback:
                k = (c.pid, c.raddr.ip, c.raddr.port)
                if k not in self.seen:
                    self.seen.add(k); ev.append({"kind": "connection", "dst_ip": c.raddr.ip, "dst_port": c.raddr.port, "process": _pname(c.pid), "pid": c.pid or 0})
            elif c.status == "LISTEN" and c.laddr.port not in self.ports:
                self.ports.add(c.laddr.port); ev.append({"kind": "listening_port", "port": c.laddr.port, "process": _pname(c.pid), "new": True})
        return ev[:300]

def local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("192.0.2.1", 9)); return s.getsockname()[0]   # no packet is sent
    except OSError: return None

class Client:
    def __init__(self, url, key): self.url, self.key = url.rstrip("/") + "/api/agent/report", key
    def send(self, body):
        req = urllib.request.Request(self.url, json.dumps(body).encode(), {"Content-Type": "application/json", "X-API-Key": self.key})
        return json.loads(urllib.request.urlopen(req, timeout=10).read())

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", default=os.getenv("CROWS_EYE_URL", "http://127.0.0.1:8000"))
    ap.add_argument("--interval", type=int, default=10)
    ap.add_argument("--auth-log", default=next((p for p in ("/var/log/auth.log", "/var/log/secure") if os.path.exists(p)), ""))
    for f in ("processes", "connections", "auth-log"): ap.add_argument(f"--no-{f}", action="store_true", help=f"disable {f} collection")
    ap.add_argument("--once", action="store_true", help="report once and exit (testing)")
    a = ap.parse_args()
    key = os.getenv("CROWS_EYE_API_KEY") or sys.exit("Set CROWS_EYE_API_KEY")
    if not a.url.startswith("https://") and not ipaddress_is_local(a.url):
        log("WARNING: sending data and API key over plain HTTP to a non-local host; use HTTPS")
    cl, stop = Client(a.url, key), [False]
    for sg in (signal.SIGINT, signal.SIGTERM): signal.signal(sg, lambda *_: stop.__setitem__(0, True))
    procs = None if a.no_processes else Processes()
    conns = None if a.no_connections else Connections()
    auth = AuthLog(a.auth_log) if a.auth_log and not a.no_auth_log else None
    log(f"v{VERSION} -> {a.url} every {a.interval}s | monitoring: metrics+traffic"
        + (", processes" if procs else "") + (", connections/ports" if conns else "") + (f", auth log {a.auth_log}" if auth else ""))
    psutil.cpu_percent(None); last_io, last_t = psutil.net_io_counters(), time.time()
    backlog = collections.deque(maxlen=5000)
    root = os.path.abspath(os.sep)
    while not stop[0]:
        for _ in range(a.interval * 2):
            if stop[0]: break
            time.sleep(.5)
        for c in (procs, conns, auth):
            if c: backlog.extend(c.poll())
        io, t = psutil.net_io_counters(), time.time(); dt = max(t - last_t, .001)
        traffic = {"inbound_mbps": (io.bytes_recv - last_io.bytes_recv) * 8 / dt / 1e6, "outbound_mbps": (io.bytes_sent - last_io.bytes_sent) * 8 / dt / 1e6}
        body = {"os": f"{platform.system()} {platform.release()}", "ip": local_ip(), "version": VERSION, "traffic": traffic,
                "metrics": {"cpu_percent": psutil.cpu_percent(None), "mem_percent": psutil.virtual_memory().percent, "disk_percent": psutil.disk_usage(root).percent}}
        batch = [backlog.popleft() for _ in range(min(400, len(backlog)))]
        try:
            r = cl.send({**body, "events": batch}); last_io, last_t = io, t
            if batch or r.get("threats"): log(f"sent {r['accepted']} events, {r['threats']} detections")
        except urllib.error.HTTPError as e:
            log(f"server rejected report: HTTP {e.code}" + (" (invalid/revoked API key)" if e.code == 401 else "")); backlog.extendleft(reversed(batch))
        except Exception as e:
            log(f"send failed ({e}); {len(backlog) + len(batch)} events buffered"); backlog.extendleft(reversed(batch))
        if a.once: break
    log("stopped")

def ipaddress_is_local(url):
    host = re.sub(r"^https?://", "", url).split("/")[0].split(":")[0]
    return host in ("localhost", "127.0.0.1", "::1")

if __name__ == "__main__": main()
